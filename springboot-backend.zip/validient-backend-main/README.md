# Validient-backend (API)

# Setup

Change these credentials in the `application.properties`

```properties
spring.datasource.url=jdbc:mysql://localhost:<mysql-port>/<database-name>
spring.datasource.username=<database-username>
spring.datasource.password=<password>
spring.jpa.hibernate.ddl-auto= update
spring.jpa.show-sql=false
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.globally_quoted_identifiers=true
#spring.jpa.properties.hibernate.enable_lazy_load_no_trans=true
```
After changing these details for the first run error may pop in the console due to joi tables but for subsequent runs all will be okay


For the api docs navigate to

http://localhost:8080/swagger-ui/index.html#/

On starting the application since the will be started on port `8080`
this will contain all the endpoints registered in the app for data querying

To initiate user roles sending post request should make the necessary roles into the database

http://localhost:8080/api/v1/auth/init

Afterwards you can register account and on the database add a record in the

| user_side_id | role_side_id |
|--------------|--------------|
| 1            | 1            |
| 1            | 3            |
| 2            | 3            |
| 3            | 2            |


```text
user(id=1) Role(id=1) and Role(id=3) # Admin and user roles
user(id=2) Role(id=3) # user role
user(id=3) Role(id=2) # lawyer role

```

This definition for user having `ADMIN` and `USER` roles
To add a user role you just add via this table

Any request sent will return unauthorized and only use `Bearer ` token for authentication

For the case of database details changed on the `application.properties` file to interop with required `MySQL`

# Dependency installation
If `maven` is installed globally we can use 
```shell
 mvn dependency:resolve
```
This will install all the dependencies

For the project maven we can use
```shell
 ./mvn dependency:resolve
```
# Running app on cli
```shell
mvn spring-boot:run 
```