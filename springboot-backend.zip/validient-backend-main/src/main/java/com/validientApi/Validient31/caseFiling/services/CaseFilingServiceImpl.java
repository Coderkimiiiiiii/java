package com.validientApi.Validient31.caseFiling.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.caseDefendant.dao.CaseDefendantDao;
import com.validientApi.Validient31.caseDefendant.entity.CaseDefendant;
import com.validientApi.Validient31.caseFiling.dao.CaseFilingDao;
import com.validientApi.Validient31.caseFiling.entity.CaseFiling;
import com.validientApi.Validient31.caseFiling.requests.CreateCaseFilingRequest;
import com.validientApi.Validient31.caseStatus.dao.CaseStatusDao;
import com.validientApi.Validient31.caseStatus.entity.CaseStatus;
import com.validientApi.Validient31.caseType.dao.CaseTypeDao;
import com.validientApi.Validient31.caseType.entity.CaseType;
import com.validientApi.Validient31.lawyer.dao.LawyerDao;
import com.validientApi.Validient31.lawyer.entity.Lawyer;
import com.validientApi.Validient31.users.dao.UserDao;
import com.validientApi.Validient31.users.entity.User;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
@NoArgsConstructor
@Data
@Transactional
public class CaseFilingServiceImpl implements CaseFilingService {
    @Autowired
    private CaseFilingDao caseFilingDao;
    @Autowired
    private CaseStatusDao caseStatusDao;
    @Autowired
    private CaseDefendantDao caseDefendantDao;
    @Autowired
    private LawyerDao lawyerDao;
    @Autowired
    private UserDao userDao;

    @Autowired
    private CaseTypeDao caseTypeDao;

    /**
     * @param plaintiffId
     * @param caseReq
     * @return
     */
    @Override
    public Optional<CaseFiling> createCaseFiling(Long plaintiffId, CreateCaseFilingRequest caseReq) throws ValidientException {
        if (!lawyerDao.existsById(caseReq.getLawyer())){
            throw ValidientException.builder().message("Lawyer not found").build();
        }
        CaseType caseType = caseTypeDao.findById(caseReq.getCaseType()).get();
        User plaintiff = userDao.findById(plaintiffId).get();
        CaseStatus caseStatus = caseStatusDao.findById(caseReq.getStatus()).get();
        Lawyer caseLawyer = lawyerDao.findById(caseReq.getLawyer()).get();

        CaseFiling newCaseFiling = CaseFiling.builder()
                .status(caseStatus)
                .caseType(caseType)
                .title(caseReq.getTitle())
                .description(caseReq.getDescription())
                .plaintiff(plaintiff)
                .lawyer(caseLawyer)
                .dateFiled(caseReq.getDateFiled())
                .build();

        return Optional.of(caseFilingDao.save(newCaseFiling));
    }

    /**
     * @param caseId
     * @param caseFilingRequest
     * @return
     */
    @Override
    public Optional<CaseFiling> updateCaseFiling(Long caseId, CreateCaseFilingRequest caseFilingRequest) throws ValidientException {
        Optional<CaseFiling> existing = caseFilingDao.findById(caseId);
        if ( existing==null){
            throw ValidientException.builder().message("No case filing").build();
        }

        return existing;
    }

    /**
     * @param caseId
     * @param lawyers
     * @return
     */
    @Override
    public Optional<CaseFiling> addLawyerToCaseFiling(Long caseId, Long lawyerId) throws ValidientException {

if (!lawyerDao.existsById(lawyerId)){
    throw ValidientException.builder().message("Lawyer not found").build();
}
       CaseFiling caseFiling = caseFilingDao.findById(caseId).get();
caseFiling.setLawyer(lawyerDao.findById(lawyerId).get());

        return Optional.of(caseFilingDao.save(caseFiling));
    }

    private CaseFiling getCaseForAddingLawyerToCase(Long caseId, Long[] lawyers) throws ValidientException {
        CaseFiling caseFiling = caseFilingDao.findById(caseId).get();
        if (caseFiling==null) {
            throw ValidientException.builder().message("Case not found").build();
        }
        List<Lawyer> caseLawyers = lawyerDao.findLawyersByIdIsIn(lawyers).get();
        if (caseLawyers.isEmpty()) {
            throw ValidientException.builder().message("No defendants found").build();
        }
        return caseFiling;
    }

    @Override
    public Optional<CaseFiling> removeLawyerFromCaseFiling(Long caseId, Long lawyerId) throws ValidientException {

        if (!lawyerDao.existsById(lawyerId)){
            throw ValidientException.builder().message("Lawyer not found").build();
        }
        CaseFiling caseFiling = caseFilingDao.findById(caseId).get();
        caseFiling.setLawyer(null);
        return Optional.of(caseFilingDao.save(caseFiling));
    }

    /**
     * @param caseId
     * @param defendants
     * @return
     */
//    @Override
//    public Optional<CaseFiling> addDefendantToCaseFiling(Long caseId, Long[] defendants) throws ValidientException {
//
//        CaseFiling caseFiling = getCaseForDefendant(caseId, defendants);
//        caseFiling
//
//                .getDefendants().forEach((caseDefendant) -> {
//                    if (!caseFiling.getDefendants().contains(caseDefendant)) {
//                        caseFiling.getDefendants().add(caseDefendant);
//                    }
//                });
//        return Optional.of(caseFilingDao.save(caseFiling));
//    }

    private CaseFiling getCaseForDefendant(Long caseId, Long[] defendants) throws ValidientException {
        CaseFiling caseFiling =caseFilingDao.findById(caseId).get();
       if (caseFiling==null) {
                throw ValidientException.builder().message("Case not found").build();

        }
        Optional<List<CaseDefendant>> caseDefendants = Optional.of(caseDefendantDao.findCaseDefendantsByIdIsIn(defendants).get());
        if (caseDefendants.isEmpty()) {
            throw new RuntimeException("No defendants found");
        }
        return caseFiling;
    }

//    @Override
//    public Optional<CaseFiling> removeDefendantToCaseFiling(Long caseId, Long[] defendants) throws ValidientException {
//        CaseFiling caseFiling = getCaseForDefendant(caseId, defendants);
//        caseFiling
//
//                .getDefendants().forEach((caseDefendant) -> {
//                    if (caseFiling.getDefendants().contains(caseDefendant)) {
//                        caseFiling.getDefendants().remove(caseDefendant);
//                    }
//                });
//        return Optional.of(caseFilingDao.save(caseFiling));
//
//    }

    /**
     * @return
     */
    @Override
    public Optional<List<CaseFiling>> findCases() throws ValidientException {

        List<CaseFiling> optionalCaseFiling = caseFilingDao.findAll();//.findAll().stream().filter(caseFiling -> caseFiling.getStatus().getId() == status)).stream().findFirst().stream().collect(Collectors.toList()).get(0);
        if (optionalCaseFiling.toArray().length<1) {
            throw ValidientException.builder().message("No case found").build();
        }
        return Optional.of(optionalCaseFiling);
    }

    /**
     * @param status
     * @return
     */
    @Override
    public Optional<List<CaseFiling>> findCasesWithStatus(Long status) throws ValidientException {

        List<CaseFiling> optionalCaseFiling = caseFilingDao.findCaseFilingsByStatus(caseStatusDao.findById(status));//.findAll().stream().filter(caseFiling -> caseFiling.getStatus().getId() == status)).stream().findFirst().stream().collect(Collectors.toList()).get(0);
        if (optionalCaseFiling.toArray().length<1) {
            throw ValidientException.builder().message("No case found").build();
        }
        return Optional.of(optionalCaseFiling);
    }

    /**
     * @param caseType
     * @return
     */
    @Override
    public Optional<List<CaseFiling>> findCasesWithType(Long caseType) throws ValidientException {
        List<CaseFiling> optionalCaseFiling = caseFilingDao.findCaseFilingsByCaseType(caseTypeDao.findById(caseType));//.findAll().stream().filter(caseFiling -> caseFiling.getStatus().getId() == status)).stream().findFirst().stream().collect(Collectors.toList()).get(0);
        if (optionalCaseFiling.toArray().length<1) {
            throw ValidientException.builder().message("No case found").build();
        }
        return Optional.of(optionalCaseFiling);
    }

    @Override
    public Optional<List<CaseFiling>> findUserCases(Long userId) throws ValidientException {
        if (!userDao.existsById(userId)){
            throw ValidientException.builder().message("Plaintiff not found").build();
        }
        return Optional.ofNullable(caseFilingDao.findCaseFilingsByPlaintiff(userDao.findById(userId).get()));
    }

    @Override
    public Optional<CaseFiling> findCaseFilingById(Long id) throws ValidientException {
        if(!caseFilingDao.existsById(id)){
            throw ValidientException.builder().message("Case filing not found").build();

        }

        return Optional.of(caseFilingDao.findById(id).get());
    }
}
