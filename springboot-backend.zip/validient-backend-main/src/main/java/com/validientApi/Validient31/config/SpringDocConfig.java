package com.validientApi.Validient31.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.annotations.OpenAPI31;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;

import java.util.ArrayList;
import java.util.List;

@OpenAPI31
@ConfigurationProperties(prefix = "docs")
public class SpringDocConfig {
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI().info(
                new io.swagger.v3.oas.models.info
                        .Info()
                        .title("Validient Api")
                        .description("API to manage law firm on cases,appointments,clisnts and track cases")
                        .version("1.0.0")
//                        .contact()
        );
//                .security(new ArrayList<>(new SecurityRequirement))
    }
}
