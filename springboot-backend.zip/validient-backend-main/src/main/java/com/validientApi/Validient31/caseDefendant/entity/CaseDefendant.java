package com.validientApi.Validient31.caseDefendant.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.validientApi.Validient31.caseFiling.entity.CaseFiling;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Data
public class CaseDefendant {
    @Id
    @GeneratedValue
    private Long id;
    @Column(nullable = false)
    private String firstName;
    @Column(nullable = false)
    private String lastName;
    @Column(nullable = false)
    private UUID identity=UUID.randomUUID();
    @JsonIgnore
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id")
    private CaseFiling caseFile;

}

