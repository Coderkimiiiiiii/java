package com.validientApi.Validient31.auth.requests;

import com.validientApi.Validient31.users.enums.Gender;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequest {
        @Email
        @NotEmpty
        private String email;
        @Size(min = 8,max = 32,message = "Password should have minimum of 8-32 characters")
        @NotNull
        @NotEmpty
        private String password;
        @NotNull
        @NotEmpty
        private String username;
        @NotNull
        @NotEmpty
        private String firstName;
        @NotNull
        @NotEmpty
        private String lastName;
        @Enumerated(EnumType.STRING)
        private Gender gender;
        private String avatar;

}
