package com.validientApi.Validient31.schedules.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.validientApi.Validient31.users.entity.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Schedule {
    @Id
    @GeneratedValue
    private Long id;
    @Column(nullable = false)
    private String title;
    private String description;
    private Long year;
    private Long month;
    private Long date;
    private Long startHour;
    private Long startMinute;
    @ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_user_id")
    private User user;
}
