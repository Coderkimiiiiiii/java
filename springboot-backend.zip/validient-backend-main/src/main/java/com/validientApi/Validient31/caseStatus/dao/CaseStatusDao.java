package com.validientApi.Validient31.caseStatus.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.validientApi.Validient31.caseStatus.entity.CaseStatus;

import java.util.Optional;

@Repository
public interface CaseStatusDao extends JpaRepository<CaseStatus, Long> {
    Optional<CaseStatus> findCaseStatusByName(String name);
    Boolean existsByName(String name);
}
