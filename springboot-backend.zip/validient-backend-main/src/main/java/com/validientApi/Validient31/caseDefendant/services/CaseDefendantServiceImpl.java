package com.validientApi.Validient31.caseDefendant.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.caseDefendant.dao.CaseDefendantDao;
import com.validientApi.Validient31.caseDefendant.entity.CaseDefendant;
import com.validientApi.Validient31.caseDefendant.requests.CreateCaseDefendant;
import com.validientApi.Validient31.caseFiling.dao.CaseFilingDao;
import com.validientApi.Validient31.caseFiling.entity.CaseFiling;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class CaseDefendantServiceImpl implements CaseDefendantService {
    @Autowired
    private CaseDefendantDao caseDefendantDao;
    @Autowired
    private CaseFilingDao caseFilingDao;
    /**
     * @param caseDefendant
     * @return
     */
    @Override
    public Optional<Object> createCaseDefendant(CreateCaseDefendant caseDefendant) throws ValidientException {
        Optional<CaseFiling> caseFiling = caseFilingDao.findById(caseDefendant.getCaseId());
        if (caseFiling==null){
            throw ValidientException.builder()
                    .statusCode(404)
                    .message("case not found")
                    .metadata("case/not existing")
                    .build();
        }
        CaseDefendant caseDefendant1 = CaseDefendant.builder()
                .firstName(caseDefendant.getFirstName())
                .lastName(caseDefendant.getLastName())
                .caseFile(caseFiling.get())
                .build();
        return Optional.of(caseDefendantDao.save(caseDefendant1));
    }

    /**
     * @param defendantId
     * @param caseDefendant
     * @return
     */
    @Override
    public Optional<CaseDefendant> updateCaseDefendant(Long defendantId, CreateCaseDefendant caseDefendant) throws ValidientException {
        Optional<CaseDefendant> caseDefendant1 = caseDefendantDao.findById(defendantId);
        Optional<CaseFiling> caseFiling = caseFilingDao.findById(caseDefendant.getCaseId());
        if (caseDefendant1==null){
            throw ValidientException.builder()
                    .statusCode(404)
                    .message("Defendant not found")
                    .metadata("case/not existing")
                    .build();
        }
        caseDefendant1.get().setFirstName(caseDefendant.getFirstName());
        caseDefendant1.get().setLastName(caseDefendant.getLastName());
        caseDefendant1.get().setCaseFile(caseFiling.get());
        return Optional.of(caseDefendantDao.save(caseDefendant1.get()));
    }

    /**
     * @param caseId
     * @return
     */
    @Override
    public List<CaseDefendant> findCaseDefendants(Long caseId) throws ValidientException {
        List<CaseDefendant> caseDefendants = caseDefendantDao.findCaseDefendantsByCaseFile_Id(caseId);
        if (caseDefendants.toArray().length<1){
            throw ValidientException.builder()
                    .statusCode(404)
                    .message("No defendants for this case")
                    .metadata("case/not existing")
                    .build();
        }
        return caseDefendants;
    }

    /**
     * @return
     */
    @Override
    public List<CaseDefendant> findDefendants() throws ValidientException {
        List<CaseDefendant> caseDefendants = caseDefendantDao.findAll();//(caseId);
        if (caseDefendants.toArray().length<1){
            throw ValidientException.builder()
                    .statusCode(404)
                    .message("No defendants for this case")
                    .metadata("defendant/not existing")
                    .build();
        }
        return caseDefendants;

    }

    /**
     * @param defendantId
     * @return
     */
    @Override
    public Optional<CaseDefendant> findCaseDefendantById(Long defendantId) throws ValidientException {
        Optional<CaseDefendant> caseDefendant = caseDefendantDao.findById(defendantId);
        if (caseDefendant==null){
            throw ValidientException.builder()
                    .statusCode(404)
                    .message("No defendant found")
                    .metadata("defendant/not existing")
                    .build();
        }
        return caseDefendant;
    }

    @Override
    public Optional<CaseDefendant> deleteCaseDefendant(Long defendantId) throws ValidientException {
        Optional<CaseDefendant> caseDefendant = caseDefendantDao.findById(defendantId);
        if (caseDefendant==null){
            throw ValidientException.builder()
                    .statusCode(404)
                    .message("No defendant found")
                    .metadata("defendant/not existing")
                    .build();
        }
        caseDefendantDao.deleteById(defendantId);
        return  caseDefendant;
    }
}
