package com.validientApi.Validient31.appointments.dao;

import com.validientApi.Validient31.appointments.entity.Appointment;
import com.validientApi.Validient31.users.entity.User;
import jakarta.persistence.TypedQuery;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface AppointmentDao extends JpaRepository<Appointment,Long> {
    Set<Appointment> findAppointmentsByMembersContaining(Long userId);
    Appointment findByTitle(String title);
    Set<Appointment> findByOwner(Long userId);
    Boolean existsByTitle(String title);

}
