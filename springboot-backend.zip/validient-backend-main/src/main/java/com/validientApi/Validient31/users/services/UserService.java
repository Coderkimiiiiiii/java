package com.validientApi.Validient31.users.services;

import java.util.Optional;
import java.util.List;
import java.util.Set;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.users.entity.User;
import com.validientApi.Validient31.users.requests.CreateUserRequest;
import com.validientApi.Validient31.users.requests.CreateUserWithRolesRequest;
import com.validientApi.Validient31.users.requests.UpdateUserPasswordRequest;
import com.validientApi.Validient31.users.requests.UpdateUserWithoutPasswordRequest;
import lombok.SneakyThrows;

public interface UserService {
    User createUser(CreateUserRequest userRequest);

    User creatUserWithRole(CreateUserRequest user, Long roleId) throws ValidientException;

    List<User> findUsers() throws ValidientException;

    User findUserByEmail(String email) throws ValidientException;

    User findUserByUsername(String email) throws ValidientException;
    List<User> findUsersByRole(Long role) throws ValidientException;
    Optional<User> findUserById(Long id) throws ValidientException;

    User addRolesToUser(Long userId, Set<Long> roleId);
    User removeRolesFromUser(Long userId,Set<Long> roleIds) throws ValidientException;
//    List<User> findUsersByRole(Long roleId);
    User createUserWithRoles(CreateUserWithRolesRequest request) throws ValidientException;
    User updateUserWithoutPassword(Long userId, UpdateUserWithoutPasswordRequest request) throws ValidientException;
    User updateUserPassword(Long userId, UpdateUserPasswordRequest request) throws ValidientException;

}
