package com.validientApi.Validient31.caseFiling.dao;

import com.validientApi.Validient31.caseFiling.entity.CaseFiling;
import com.validientApi.Validient31.caseStatus.entity.CaseStatus;
import com.validientApi.Validient31.caseType.entity.CaseType;
import com.validientApi.Validient31.users.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CaseFilingDao extends JpaRepository<CaseFiling,Long> {
    List<CaseFiling> findCaseFilingsByCaseType(Optional<CaseType> caseType);
    List<CaseFiling> findCaseFilingsByStatus(Optional<CaseStatus> caseStatus);
    List <CaseFiling> findCaseFilingsByPlaintiff(User plaintiff);
}
