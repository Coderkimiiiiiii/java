package com.validientApi.Validient31.caseDefendant.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.caseDefendant.entity.CaseDefendant;
import com.validientApi.Validient31.caseDefendant.requests.CreateCaseDefendant;

import java.util.List;
import java.util.Optional;

public interface CaseDefendantService {
    Optional<Object> createCaseDefendant(CreateCaseDefendant caseDefendant) throws ValidientException;
    Optional<CaseDefendant> updateCaseDefendant(Long defendantId, CreateCaseDefendant caseDefendant) throws ValidientException;
    List<CaseDefendant>  findCaseDefendants(Long caseId) throws ValidientException;
    List<CaseDefendant>  findDefendants() throws ValidientException;
    Optional<CaseDefendant> findCaseDefendantById(Long defendantId) throws ValidientException;
    Optional<CaseDefendant> deleteCaseDefendant(Long defendantId) throws ValidientException;

}
