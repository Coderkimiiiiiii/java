package com.validientApi.Validient31.lawyer.entity;

import java.util.Set;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.validientApi.Validient31.caseFiling.entity.CaseFiling;
import com.validientApi.Validient31.caseType.entity.CaseType;
import com.validientApi.Validient31.users.entity.User;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Data
@JsonSerialize
public class Lawyer {
    @Id
    @GeneratedValue
    private Long id;
    @Column(nullable = false, unique = true)
    private Long verifiedYear;
    private Long hourlyRate;
    @Lob
    private String practiceAreas;

    @Lob
    private String notes;
    @Column(unique = true)
    private final UUID identification = UUID.randomUUID();
    @OneToMany(mappedBy="lawyer", cascade= {CascadeType.PERSIST,CascadeType.MERGE},fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<CaseFiling> caseFiles;
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "fk_user_lawyer_id", unique = true)
    private User user;
    @ManyToOne
    private CaseType caseType;

}

