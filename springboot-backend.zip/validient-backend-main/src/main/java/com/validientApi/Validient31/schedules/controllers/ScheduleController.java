package com.validientApi.Validient31.schedules.controllers;

import com.validientApi.Validient31.schedules.entity.Schedule;
import com.validientApi.Validient31.schedules.requests.CreateScheduleRequest;
import com.validientApi.Validient31.schedules.services.ScheduleService;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@NoArgsConstructor
@Data
@RestController
@RequestMapping("/api/v1/schedules")
public class ScheduleController {
    @Autowired
    private ScheduleService scheduleService;

    @SneakyThrows
    @GetMapping
    @PreAuthorize("hasAnyAuthority('ADMIN','USER','LAWYER')")
    public ResponseEntity<Optional<List<Schedule>>> getSchedules() {
        return ResponseEntity.ok().body(Optional.ofNullable(scheduleService.getSchedules()));
    }

    @SneakyThrows
    @GetMapping("/user/{userId}")
    @PreAuthorize("hasAnyAuthority('ADMIN','LAWYER','USER')")
    public ResponseEntity<List<Schedule>> getSchedules(
            @PathVariable Long userId
    ) {
        return ResponseEntity.ok().body(scheduleService.getUserSchedules(userId));
    }

    @SneakyThrows
    @PostMapping("/user/{userId}/create")
    @PreAuthorize("hasAnyAuthority('ADMIN','LAWYER','USER')")
    public ResponseEntity<Schedule> createUserSchedule(
            @PathVariable Long userId,
            @RequestBody CreateScheduleRequest request
    ) {
        return ResponseEntity.ok().body(scheduleService.createSchedule(userId, request));
    }
    @SneakyThrows
    @PutMapping("/user/{scheduleId}/update/")
    @PreAuthorize("hasAnyAuthority('ADMIN','LAWYER','USER')")
    public ResponseEntity<Schedule> updateUserSchedule(
            @PathVariable Long scheduleId,
            @RequestBody CreateScheduleRequest request
    ) {
        return ResponseEntity.ok().body(scheduleService.updateSchedule(scheduleId, request));
    }
    @SneakyThrows
    @GetMapping("/user/{scheduleId}/get")
    @PreAuthorize("hasAnyAuthority('ADMIN','LAWYER','USER')")
    public ResponseEntity<Optional<Schedule>> getScheduleById(
            @PathVariable Long scheduleId
    ) {
        return ResponseEntity.ok().body(scheduleService.getScheduleById(scheduleId));
    }
    @SneakyThrows
    @DeleteMapping("/user/{scheduleId}/delete")
    @PreAuthorize("hasAnyAuthority('ADMIN','LAWYER','USER')")
    public ResponseEntity<Optional<Schedule>> deleteSchedule(
            @PathVariable Long scheduleId
    ) {
        return ResponseEntity.ok().body(scheduleService.deleteSchedule(scheduleId));
    }

}
