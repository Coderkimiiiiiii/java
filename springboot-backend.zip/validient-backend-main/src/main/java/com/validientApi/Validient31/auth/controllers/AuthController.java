package com.validientApi.Validient31.auth.controllers;


import com.validientApi.Validient31.advice.ApiError;
import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.auth.requests.LoginRequest;
import com.validientApi.Validient31.auth.requests.RegisterRequest;
import com.validientApi.Validient31.auth.responses.RegistrationResponse;
import com.validientApi.Validient31.auth.services.AuthService;
import com.validientApi.Validient31.roles.entity.Role;
import com.validientApi.Validient31.roles.services.RoleService;
import com.validientApi.Validient31.users.entity.User;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final RoleService roleService;

    @SneakyThrows
    @PostMapping("/register")
    public RegistrationResponse register(
            @Valid @RequestBody RegisterRequest request
    ) {
        return ResponseEntity.ok().body(authService.register(request)).getBody();
    }

//    @SneakyThrows
    @PostMapping("/login")
    public ResponseEntity<Object> authenticate(
            @RequestBody @Valid LoginRequest request
    ) {
        try {
            return ResponseEntity.ok((authService.authenticate(request)));
        }catch (ValidientException e){
            return ResponseEntity.ok().body(e.getMessage());
        }
        catch (Exception e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @SneakyThrows
    @PostMapping("/init")
    public ResponseEntity<Optional<List<Role>>> initializeApp() {

        return ResponseEntity.ok().body(roleService.initializeRoles());

    }

    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','USER','ADMIN'})")
    @GetMapping("/profile/{username}")
    public ResponseEntity<User> getUserProfile(@PathVariable("username") @NotNull @NotEmpty @NotBlank String username) {
        try {


            return ResponseEntity.ok().body(authService.getUserprofile(username));
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new RuntimeException(e);
        }
    }


}
