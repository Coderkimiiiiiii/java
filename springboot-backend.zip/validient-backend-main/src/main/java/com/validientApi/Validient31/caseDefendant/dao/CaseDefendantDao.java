package com.validientApi.Validient31.caseDefendant.dao;

import com.validientApi.Validient31.caseDefendant.entity.CaseDefendant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface CaseDefendantDao extends JpaRepository<CaseDefendant,Long> {
    Optional<List<CaseDefendant>> findCaseDefendantsByIdIsIn(Long[] ids);
    List<CaseDefendant> findCaseDefendantsByCaseFile_Id(Long caseFileId);
}
