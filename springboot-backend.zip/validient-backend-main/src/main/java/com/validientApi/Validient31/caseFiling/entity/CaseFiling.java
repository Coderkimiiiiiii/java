package com.validientApi.Validient31.caseFiling.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.validientApi.Validient31.caseDefendant.entity.CaseDefendant;
import com.validientApi.Validient31.caseStatus.entity.CaseStatus;
import com.validientApi.Validient31.caseType.entity.CaseType;
import com.validientApi.Validient31.lawyer.entity.Lawyer;
import com.validientApi.Validient31.users.entity.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Data
@JsonIgnoreProperties({"hibernateLazyInitializer"})
public class CaseFiling {
    @Id
    @GeneratedValue
    private Long id;
    @Column(nullable = false)
    private String title;
    @Lob
    private String description;
    private String dateFiled;
    private final UUID caseId = UUID.randomUUID();
    @ManyToOne(cascade = {CascadeType.MERGE,CascadeType.PERSIST},fetch = FetchType.LAZY)
    @JoinColumn(name = "fk_type")
    private CaseType caseType;
    @ManyToOne(cascade = {CascadeType.MERGE,CascadeType.PERSIST},fetch = FetchType.LAZY)
    @JoinColumn(name = "fk_status")
    private CaseStatus status;
    @ManyToOne
    private Lawyer lawyer;
//    @OneToMany(mappedBy = "caseFile", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<CaseDefendant> defendants;
    @ManyToOne(cascade = {CascadeType.MERGE,CascadeType.PERSIST},fetch = FetchType.LAZY)
    @JoinColumn(name = "fk_plaintiff")
    private User plaintiff;
}
