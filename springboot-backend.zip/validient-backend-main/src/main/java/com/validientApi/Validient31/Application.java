package com.validientApi.Validient31;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.validientApi.Validient31.config.SpringDocConfig;

@SpringBootApplication
@EnableConfigurationProperties(SpringDocConfig.class)
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}


}
