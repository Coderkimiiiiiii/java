package com.validientApi.Validient31.caseFiling.controllers;

import com.validientApi.Validient31.caseFiling.entity.CaseFiling;
import com.validientApi.Validient31.caseFiling.requests.CreateCaseFilingRequest;
import com.validientApi.Validient31.caseFiling.services.CaseFilingService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@AllArgsConstructor
@NoArgsConstructor
@RequestMapping("/api/v1/cases")
public class CaseFilingController {
    @Autowired
    private CaseFilingService caseFilingService;
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','ADMIN','USER'})")
    @GetMapping
    public ResponseEntity<Optional<List<CaseFiling>>> getAllCaseFilings(){
        return ResponseEntity.ok().body(caseFilingService.findCases());
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','ADMIN','USER'})")
    @GetMapping("/{caseId}/get")
    public ResponseEntity<Optional<CaseFiling>> getCaseById(@PathVariable @NotNull Long caseId){
        return ResponseEntity.ok().body(caseFilingService.findCaseFilingById(caseId));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','ADMIN','USER'})")
    @GetMapping("/status/{statusId}/get")
    public ResponseEntity<Optional<List<CaseFiling>>> getCasesWithStatus(
            @PathVariable("statusId") @NotNull @NotEmpty @NotBlank Long statusId
    ){
        return ResponseEntity.ok().body(caseFilingService.findCasesWithStatus(statusId));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','ADMIN','USER'})")
    @GetMapping("/status/{typeId}/get")
    public ResponseEntity<Optional<List<CaseFiling>>> getCasesByType(
            @PathVariable("typeId") @NotNull @NotEmpty @NotBlank Long typeId
    ){
        return ResponseEntity.ok().body(caseFilingService.findCasesWithType(typeId));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','ADMIN','USER'})")
    @GetMapping("/plaintiff/{userId}/get-cases")
    public ResponseEntity<Optional<List<CaseFiling>>> getUserCases(
            @PathVariable("userId") @NotNull @NotEmpty @NotBlank Long userId
    ){
        return ResponseEntity.ok().body(caseFilingService.findUserCases(userId));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'ADMIN'})")
    @PostMapping("/{plaintiffId}/create")
    public ResponseEntity<Optional<CaseFiling>> getAllCaseFilings(
            @PathVariable("plaintiffId") @NotNull Long plaintiffId,
            @RequestBody @Valid CreateCaseFilingRequest request
            ){
        return ResponseEntity.ok().body(caseFilingService.createCaseFiling(plaintiffId,request));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'ADMIN','LAWYER'})")
    @PutMapping("/{caseId}/update")
    public ResponseEntity<Optional<CaseFiling>> updateCaseFiling(
            @PathVariable("caseId") @NotNull @NotEmpty @NotBlank Long caseId,
            @RequestBody @Valid CreateCaseFilingRequest request
    ){
        return ResponseEntity.ok().body(caseFilingService.updateCaseFiling(caseId,request));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'ADMIN'})")
    @PutMapping("/lawyer/{caseId}/change-lawyer")
    public ResponseEntity<Optional<CaseFiling>> addLawyersToCase(
            @PathVariable("caseId") @NotNull @NotEmpty @NotBlank Long caseId,
            @RequestPart("lawyers") @NotNull @NotBlank @NotEmpty Long lawyerId
    ){
        return ResponseEntity.ok().body(caseFilingService.addLawyerToCaseFiling(caseId,lawyerId));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'ADMIN'})")
    @PutMapping("/lawyer/{caseId}/remove-lawyer")
    public ResponseEntity<Optional<CaseFiling>> removeLawyersFromCase(
            @PathVariable("caseId") @NotNull @NotEmpty @NotBlank Long caseId,
            @RequestPart("lawyers") @NotNull @NotBlank @NotEmpty Long lawyerId
    ){
        return ResponseEntity.ok().body(caseFilingService.removeLawyerFromCaseFiling(caseId,lawyerId));
    }
//    @SneakyThrows
//    @PreAuthorize("hasAnyAuthority({'ADMIN'})")
//    @PutMapping("/defendant/{caseId}/add-defendant")
//    public ResponseEntity<Optional<CaseFiling>> addDefendantsToCase(
//            @PathVariable("caseId") @NotNull @NotEmpty @NotBlank Long caseId,
//            @RequestPart("lawyers") @NotNull @NotBlank @NotEmpty Long[] lawyers
//    ){
//        return ResponseEntity.ok().body(caseFilingService.addDefendantToCaseFiling(caseId,lawyers));
//    }
//    @SneakyThrows
//    @PreAuthorize("hasAnyAuthority({'ADMIN','LAWYER'})")
//    @PutMapping("/defendant/{caseId}/remove-defendant")
//    public ResponseEntity<Optional<CaseFiling>> removeDefendantsFromCase(
//            @PathVariable("caseId") @NotNull @NotEmpty @NotBlank Long caseId,
//            @RequestPart("defendants") @NotNull @NotBlank @NotEmpty Long[] defendants
//    ){
//        return ResponseEntity.ok().body(caseFilingService.removeDefendantToCaseFiling(caseId,defendants));
//    }
}
