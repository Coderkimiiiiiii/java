package com.validientApi.Validient31.appointments.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateAppointmentRequest {
    @NotNull
    @NotNull
    @NotBlank
    private String title;
    @NotNull
    @NotEmpty
    @NotBlank
    private String description;
    @NotNull
    private Long year;
    @NotNull
    private Long month;
    @NotNull
    private Long date;

    @NotNull
    private Long startHour;

    @NotNull
    private Long startMinute;
    @NotNull
    private Long owner;

    @NotNull
    private Long[] members;
}
