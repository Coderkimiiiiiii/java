package com.validientApi.Validient31.caseStatus.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.caseStatus.dao.CaseStatusDao;
import com.validientApi.Validient31.caseStatus.entity.CaseStatus;
import com.validientApi.Validient31.caseStatus.requests.CreateCaseStatusRequest;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CaseStatusServiceImpl implements CaseStatusService {
    @Autowired
    private CaseStatusDao caseStatusDao;
    @Override
    public CaseStatus createCaseStatus(CreateCaseStatusRequest statusRequest) throws ValidientException {
        if (caseStatusDao.existsByName(statusRequest.getName())){
            throw ValidientException.builder().message("Case status with name already exist").build();
        }
        CaseStatus newCaseStatus = CaseStatus.builder()
                .name(statusRequest.getName())
                .description(statusRequest.getDescription())
                .build();
        return caseStatusDao.save(newCaseStatus);
    }

    @Override
    public CaseStatus updateCaseStatusById(Long id, CreateCaseStatusRequest updateRequest) throws ValidientException {

        Optional<CaseStatus> optionalCaseStatus= caseStatusDao.findById(id);
        if (optionalCaseStatus==null){
            throw ValidientException.builder().message("Case status with name already exist")
                    .metadata("finding/bu/id").build();
        }
        if (optionalCaseStatus.isEmpty()){
            throw ValidientException.builder().message("Case status does not exist").statusCode(404).build();
        }
        optionalCaseStatus.get().setName(updateRequest.getName());
        optionalCaseStatus.get().setDescription(updateRequest.getDescription());
        return caseStatusDao.save(optionalCaseStatus.get());
    }

    @Override
    public Optional<List<CaseStatus>> findCaseStatuses() throws ValidientException {

        List<CaseStatus> optionalCaseStatus= Optional.of(caseStatusDao.findAll()).get();
        if (optionalCaseStatus.isEmpty()){
            throw ValidientException.builder().message("No case ststuses")
                    .metadata("finding/statuses")
                    .build();
        }
        return Optional.of(optionalCaseStatus);
    }

    @Override
    public Optional<CaseStatus> findStatusByName(String name) {
        Optional<CaseStatus> optionalCaseStatus=caseStatusDao.findCaseStatusByName(name);
        if (optionalCaseStatus.isEmpty()){
            throw new RuntimeException("Case status does not exist");
        }
        return optionalCaseStatus;
    }

    @Override
    public Optional<CaseStatus> findStatusById(Long statusId) {
        Optional<CaseStatus> optionalCaseStatus=caseStatusDao.findById(statusId);
        if (optionalCaseStatus.isEmpty()){
            throw new RuntimeException("Case status does not exist");
        }
        return optionalCaseStatus;
    }

    @Override
    public Optional<CaseStatus> deleteCaseStatus(Long caseStatusId) throws ValidientException {
        Optional<CaseStatus> caseStatus1= caseStatusDao.findById(caseStatusId);
        if (caseStatus1==null){
            throw ValidientException.builder()
                    .message("Status not found")
                    .metadata("deleting status")
                    .build();
        }
        caseStatusDao.deleteById(caseStatusId);
        return caseStatus1;
    }
}
