package com.validientApi.Validient31.appointments.controllers;

import com.validientApi.Validient31.appointments.entity.Appointment;
import com.validientApi.Validient31.appointments.requests.CreateAppointmentRequest;
import com.validientApi.Validient31.appointments.services.AppointmentService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/appointments")
@RequiredArgsConstructor
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','ADMIN','USER'})")
    @GetMapping
    public ResponseEntity<List<Appointment>> getAllAppointments(){
        return ResponseEntity.ok().body(appointmentService.getAppointments());
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','ADMIN','USER'})")
    @GetMapping("/appointment/{appointmentId}/get")
    public ResponseEntity<Appointment> getAppointmentById(@PathVariable("appointmentId") @NotNull Long appointmentId) {
        return ResponseEntity.ok().body(appointmentService.getAppointmentById(appointmentId));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','USER','ADMIN'})")
    @GetMapping("/{userId}/personalAppointments")
    public ResponseEntity<List<Appointment>> getAllUserAppointments(@PathVariable("userId") @NotNull @NotEmpty @NotBlank Long userId){
        return ResponseEntity.ok().body(appointmentService.getUserAppointments(userId));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','USER','ADMIN'})")
    @GetMapping("/{userId}/member-appointments")
    public ResponseEntity<List<Appointment>> getAllMemberAppointments(@PathVariable("userId") @NotNull @NotEmpty @NotBlank Long userId){
        return ResponseEntity.ok().body(appointmentService.getAppointmentsWhereUserIsMember(userId));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','ADMIN'})")
    @PostMapping("/create/new")
    public ResponseEntity<Appointment> getAllMemberAppointments(@RequestBody @Valid CreateAppointmentRequest request){
        return ResponseEntity.ok().body(appointmentService.createAppointment(request));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','ADMIN'})")
    @PatchMapping("/{appointmentId}/add-members")
    public ResponseEntity<Appointment> addMemberToAppointments(@PathVariable("appointmentId") @NotNull @NotEmpty @NotBlank Long appointmentId, @RequestBody @Valid Long[] members){
        return ResponseEntity.ok().body(appointmentService.addUsersToAppointment(appointmentId,members));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','ADMIN'})")
    @PatchMapping("/{appointmentId}/remove-members")
    public ResponseEntity<Optional<Appointment>> removeMemberToAppointments(@PathVariable("appointmentId") @NotNull @NotEmpty @NotBlank Long appointmentId, @RequestBody @Valid Long[] members){
        return ResponseEntity.ok().body(appointmentService.removeUsersToAppointment(appointmentId,members));
    }
    @SneakyThrows
    @PreAuthorize("hasAnyAuthority({'LAWYER','ADMIN'})")
    @DeleteMapping("/{appointmentId}/delete")
    public ResponseEntity<Optional<Appointment>> deleteAppointment(@PathVariable("appointmentId") @NotNull @NotEmpty @NotBlank Long appointmentId){
        return ResponseEntity.ok().body(appointmentService.deleteAppointment(appointmentId));
    }
}
