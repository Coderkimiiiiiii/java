package com.validientApi.Validient31.appointments.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.appointments.entity.Appointment;
import com.validientApi.Validient31.appointments.requests.CreateAppointmentRequest;

import java.util.List;
import java.util.Optional;

public interface AppointmentService {
    Appointment createAppointment(CreateAppointmentRequest request) throws ValidientException;
    Appointment updateAppointment(Long appointmentId,CreateAppointmentRequest request);
    Appointment addUsersToAppointment(Long appointmentId,Long[] members) throws ValidientException;
    Optional<Appointment> removeUsersToAppointment(Long appointmentId, Long[] members) throws ValidientException;
    Optional<Appointment> deleteAppointment(Long appointmentId) throws ValidientException;
    List<Appointment> getUserAppointments(Long userId) throws ValidientException;
    Appointment getAppointmentById(Long appointmentId) throws ValidientException;
    List<Appointment> getAppointmentsWhereUserIsMember(Long userId) throws ValidientException;
    List<Appointment> getAppointments() throws ValidientException;
}
