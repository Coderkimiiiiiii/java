package com.validientApi.Validient31.caseStatus.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.caseStatus.entity.CaseStatus;
import com.validientApi.Validient31.caseStatus.requests.CreateCaseStatusRequest;

import java.util.List;
import java.util.Optional;


public interface CaseStatusService {

    CaseStatus createCaseStatus(CreateCaseStatusRequest statusRequest) throws ValidientException;

    CaseStatus updateCaseStatusById(Long id, CreateCaseStatusRequest updateRequest) throws ValidientException;

    Optional<List<CaseStatus>> findCaseStatuses() throws ValidientException;

    Optional<CaseStatus> findStatusByName(String name);
    Optional<CaseStatus> findStatusById(Long statusId);
    Optional<CaseStatus> deleteCaseStatus(Long caseStatusId) throws ValidientException;
}

