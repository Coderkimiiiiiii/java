package com.validientApi.Validient31.schedules.dao;

import com.validientApi.Validient31.schedules.entity.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ScheduleDao extends JpaRepository<Schedule,Long> {
    List<Schedule> findByUser(Long userId);
    List<Schedule> findByYearAndMonth(Long year,Long month);
}
