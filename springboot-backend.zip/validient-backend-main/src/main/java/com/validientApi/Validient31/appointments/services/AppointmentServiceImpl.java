package com.validientApi.Validient31.appointments.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.appointments.dao.AppointmentDao;
import com.validientApi.Validient31.appointments.entity.Appointment;
import com.validientApi.Validient31.appointments.requests.CreateAppointmentRequest;
import com.validientApi.Validient31.users.dao.UserDao;
import com.validientApi.Validient31.users.entity.User;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Transactional
@AllArgsConstructor
@NoArgsConstructor
@Service
@Slf4j
public class AppointmentServiceImpl implements AppointmentService {
    @Autowired
    private AppointmentDao appointmentDao;
    @Autowired
    private UserDao userDao;

    /**
     * @param request
     * @return
     */
    @Override
    public Appointment createAppointment(CreateAppointmentRequest request) throws ValidientException {

        if (!userDao.existsById(request.getOwner())){
            throw ValidientException.builder().message("Appointment creator invalid")
                    .metadata("create/appointment-failure")
                    .statusCode(400).build();
        }
        if (appointmentDao.existsByTitle(request.getTitle())) {
            throw ValidientException.builder().message("Appointment title already exist")
                    .metadata("create/appointment-failure").statusCode(409).build();
        }
        Appointment existing = appointmentDao.findByTitle(request.getTitle());
        Optional<User> appointmentOwner = userDao
                .findById(request.getOwner());
        Set<User> members = userDao
                .findAll()
                .stream()
                .filter(m -> Arrays
                        .stream(
                                request.getMembers())
                        .toList()
                        .contains(m.getId()
                        )
                ).collect(Collectors.toSet());

        Appointment newAppointment = Appointment.builder().title(request.getTitle())
                .description(request.getDescription())
                .year(request.getYear())
                .month(request.getMonth())
                .date(request.getDate())
                .startHour(request.getStartHour())
                .startMinute(request.getStartMinute())
                .owner(appointmentOwner.get())
                .members(members).build();
                newAppointment.getMembers()
                .add(appointmentOwner.get());

        return appointmentDao.save(newAppointment);
    }

    /**
     * @param appointmentId
     * @param request
     * @return
     */
    @Override
    public Appointment updateAppointment(Long appointmentId, CreateAppointmentRequest request) {
        return null;
    }

    /**
     * @param appointmentId
     * @param members
     * @return
     */
    @Override
    public Appointment addUsersToAppointment(Long appointmentId, Long[] members) throws ValidientException {

        Optional<Appointment> appointment = appointmentDao.findById(appointmentId);
        List<User> users = userDao.findAll().stream().filter(user -> Arrays.stream(members).toList().contains(user.getId())).collect(Collectors.toList());
        if (users.toArray().length < 1) {
            throw ValidientException
                    .builder()
                    .message("No members supplied")
                    .metadata("add appointment members")
                    .statusCode(404)
                    .build();
        }
        if (appointment == null) {

            throw ValidientException
                    .builder()
                    .message("Invalid appointment id")
                    .metadata("fetch/appointment-failure")
                    .statusCode(404)
                    .build();
        }
        users.forEach(user -> {
            if (!appointment.get().getMembers().contains(user)) {
                appointment.get().getMembers().add(user);
            }
        });
        return appointmentDao.save(appointment.get());
    }

    /**
     * @param appointmentId
     * @param members
     * @return
     */
    @Override
    public Optional<Appointment> removeUsersToAppointment(Long appointmentId, Long[] members) throws ValidientException {
        if (!appointmentDao.existsById(appointmentId)){
            throw ValidientException
                    .builder()
                    .message("Invalid appointment id")
                    .metadata("fetch/appointment-failure")
                    .statusCode(404)
                    .build();
        }
        Optional<Appointment> appointment = appointmentDao.findById(appointmentId);

        appointment.get().getMembers().forEach(m -> {
            if (Arrays.stream(members).toList().contains(m.getId())) {
                appointment.get().getMembers().remove(m);
            }
        });
        return Optional.of(appointmentDao.save(appointment.get()));

    }

    /**
     * @param appointmentId
     * @return
     */
    @Override
    public Optional<Appointment> deleteAppointment(Long appointmentId) throws ValidientException {
        if (!appointmentDao.existsById(appointmentId)){
            throw ValidientException
                    .builder()
                    .message("Invalid appointment id")
                    .metadata("fetch/appointment-failure")
                    .statusCode(404)
                    .build();
        }
        Optional<Appointment> appointment = appointmentDao.findById(appointmentId);
        appointmentDao.deleteById(appointmentId);
        return appointment;
    }

    /**
     * @param userId
     * @return
     */
    @Override
    public List<Appointment> getUserAppointments(Long userId) throws ValidientException {


            List<Appointment> appointments = appointmentDao.findAll()
                    .stream()
                    .filter(a->a.getOwner().getId()==userId).collect(Collectors.toList());
            if (appointments.toArray().length < 1) {
                throw ValidientException
                        .builder()
                        .message("No user appointments")
                        .metadata("fetch/appointment-failure")
                        .statusCode(404)
                        .build();
            }
            return  appointments;
        }

    @Override
    public Appointment getAppointmentById(Long appointmentId) throws ValidientException {
        if (!appointmentDao.existsById(appointmentId)){
            throw ValidientException
                    .builder()
                    .message("No user appointments")
                    .metadata("fetch/appointment-failure")
                    .statusCode(404)
                    .build();
        }
        return appointmentDao.findById(appointmentId).get();
    }

    /**
     * @param userId
     * @return
     */
    @Override
    public List<Appointment> getAppointmentsWhereUserIsMember(Long userId) throws ValidientException {
        Set<Appointment> appointments = appointmentDao.findAppointmentsByMembersContaining(userId);
        if (appointments.toArray().length < 1) {
            throw ValidientException
                    .builder()
                    .message("No user appointments")
                    .metadata("fetch/appointment-failure")
                    .statusCode(404)
                    .build();
        }
        return (List<Appointment>) appointments;
    }

    @Override
    public List<Appointment> getAppointments() throws ValidientException {
        System.out.println("----e");
        log.info("Fetching all appointments");

        List<Appointment> response = appointmentDao.findAll();

        return response;
    }
}
