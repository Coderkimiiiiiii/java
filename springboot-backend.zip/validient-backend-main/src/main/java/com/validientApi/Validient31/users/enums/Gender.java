package com.validientApi.Validient31.users.enums;

public enum Gender {
    OTHER,
    MALE,
    FEMALE,
}
