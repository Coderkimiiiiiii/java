package com.validientApi.Validient31.auth.responses;

import com.validientApi.Validient31.users.entity.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class RegistrationResponse {
    private LoginResponse auth;
   private User user;
}
