package com.validientApi.Validient31.appointments.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.validientApi.Validient31.users.entity.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Set;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class Appointment {
    @Id
    @GeneratedValue
    private Long id;
    @Column(nullable = false)
    private String title;
    private String description;
    private Long year;
    private Long month;
    private Long date;
    private Long startHour;
    private Long startMinute;
    @ManyToOne
    @JoinColumn(referencedColumnName = "id")
    private User owner;

    @ManyToMany(cascade ={CascadeType.MERGE,CascadeType.PERSIST},fetch = FetchType.EAGER)
    private Set<User> members;
}
