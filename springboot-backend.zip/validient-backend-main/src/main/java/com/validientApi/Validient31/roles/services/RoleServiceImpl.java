package com.validientApi.Validient31.roles.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.roles.dao.RoleDao;
import com.validientApi.Validient31.roles.entity.Role;
import com.validientApi.Validient31.roles.requests.CreateRoleRequest;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class RoleServiceImpl implements RoleService {
    @Autowired
    private RoleDao roleDao;

    @Override
    public Optional<List<Role>> initializeRoles() throws ValidientException {

            List<Role> roles = roleDao.findAll();
            if (roles.toArray().length>0) {
                throw ValidientException.builder().message("Roles already initialized").metadata("recurse/init").statusCode(500).build();
            }

            Role adminRole = Role.builder()
                    .name("admin")
                    .description("Admin role")
                    .isDefault(false)
                    .build();
            Role userRole = Role.builder()
                    .isDefault(true)
                    .name("user")
                    .description("User role")
                    .build();
            Role lawyerRole = Role.builder()
                    .name("lawyer")
                    .isDefault(false)
                    .description("Lawyer role")
                    .build();
            return Optional.of(roleDao.saveAll(List.of(adminRole, lawyerRole, userRole)));

    }

    @Override
    public Role createRole(CreateRoleRequest roleRequest) throws ValidientException {
       if (roleDao.existsByName(roleRequest.getName())){
           throw ValidientException.builder()
                   .message("Role already exist")
                   .metadata("trying to add existing record")
                   .build();
       }
        if (roleDao.existsByIsDefault(roleRequest.getIsDefault())){
            throw ValidientException.builder()
                    .message("Default role already exist")
                    .metadata("trying to add existing record")
                    .build();
        }
        Role newRole = Role.builder()
                .name(roleRequest.getName())
                .isDefault(roleRequest.getIsDefault())
                .description(roleRequest.getDescription())
                .build();
        return roleDao.save(newRole);
    }

    @Override
    public Role updateRole(Long roleId, CreateRoleRequest roleRequest) throws ValidientException {
        if (!roleDao.existsById(roleId)){
            throw ValidientException.builder()
                    .message("Role does not exist")
                    .metadata("trying to add existing record")
                    .build();
        }
        if (roleDao.existsByName(roleRequest.getName())){
            throw ValidientException.builder()
                    .message("Role already exist")
                    .metadata("trying to add existing record")
                    .build();
        }
        if (roleDao.existsByIsDefault(roleRequest.getIsDefault())){
            throw ValidientException.builder()
                    .message("Default role already exist")
                    .metadata("trying to add existing record")
                    .build();
        }
        Optional<Role> role = roleDao.findById(roleId);
        role.get().setDescription(roleRequest.getDescription());
        role.get().setIsDefault(roleRequest.getIsDefault());
        role.get().setName(roleRequest.getName());
        return  roleDao.save(role.get());
    }

    @Override
    public Optional<List<Role>> findRoles() {
       List<Role> roles;
        roles = roleDao.findAll();
        if (roles.isEmpty()) {
            throw new RuntimeException("No roles found");
        }
        return Optional.of(roles);
    }

    @Override
    public Role findRoleByName(String name) throws ValidientException {
        if (!roleDao.existsByName(name)) {
            throw ValidientException.builder().message("Role with " + name + " does not exist").build();
        }
        return roleDao.findRoleByName(name);
    }

    @Override
    public Optional<Role> findRoleById(Long id) throws ValidientException {
        if (!roleDao.existsById(id)){
                throw ValidientException.builder().message("Role with " + id.toString() + " does not exist").build();
        }
        return roleDao.findById(id);
    }

    @Override
    public Optional<Role> findDefaultRole(Boolean isDefault) throws ValidientException {
        if (!roleDao.existsByIsDefault(isDefault)) {
            throw ValidientException.builder().message("Default role not found").build();
        }
        Role role = roleDao.findDefaultRole(isDefault);

        return Optional.of(role);
    }
}
