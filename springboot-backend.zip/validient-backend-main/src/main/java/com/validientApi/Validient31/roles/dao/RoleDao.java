package com.validientApi.Validient31.roles.dao;

import com.validientApi.Validient31.roles.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RoleDao extends JpaRepository<Role,Long> {
    Role findRoleByName(String name);
    @Query("SELECT e FROM  Role e WHERE e.isDefault=?1")
    Role findDefaultRole(Boolean isDefault);

    Boolean existsByIsDefault(Boolean isDefault);
    Boolean existsByName(String name);
}
