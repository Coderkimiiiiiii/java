package com.validientApi.Validient31.schedules.requests;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateScheduleRequest {
    /**
     * Schedule title that uniquely identifies your schedule
     * */
    @NotEmpty
    @NotNull
    private String title;
    @NotEmpty
    @NotNull
    /**
     * Schedule description that describes your schedule
     * */
    private String description;
    @NotEmpty
    @NotNull
    /**
     * Schedule year for which it will be set
     * */
    private Long year;
    @NotEmpty
    @NotNull
    /**
     * Schedule month for which it will be set
     * */
    private Long month;
    @NotEmpty
    @NotNull
    private Long date;
    @NotEmpty
    @NotNull
    private Long startHour;
    @NotEmpty
    @NotNull
    private Long startMinute;

}
