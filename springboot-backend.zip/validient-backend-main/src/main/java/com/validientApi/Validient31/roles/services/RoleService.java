package com.validientApi.Validient31.roles.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.roles.entity.Role;
import com.validientApi.Validient31.roles.requests.CreateRoleRequest;

import java.util.List;
import java.util.Optional;

public interface RoleService {
    Optional<List<Role>> initializeRoles() throws ValidientException;
    Role createRole(CreateRoleRequest roleRequest) throws ValidientException;
    Role updateRole(Long roleId,CreateRoleRequest roleRequest) throws ValidientException;
   Optional<List<Role>> findRoles();
    Role findRoleByName(String name) throws ValidientException;
    Optional<Role> findRoleById(Long id) throws ValidientException;
    Optional<Role> findDefaultRole(Boolean defaultRole) throws ValidientException;

}
