package com.validientApi.Validient31.schedules.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.schedules.entity.Schedule;
import com.validientApi.Validient31.schedules.requests.CreateScheduleRequest;

import java.util.List;
import java.util.Optional;

public interface ScheduleService {
    Schedule createSchedule(Long userId,CreateScheduleRequest scheduleRequest) throws ValidientException;
    Schedule updateSchedule(Long scheduleId,CreateScheduleRequest scheduleRequest) throws ValidientException;
    List<Schedule> getSchedules() throws ValidientException;
    List<Schedule> getUserSchedules(Long userId) throws ValidientException;
    Optional<Schedule> getScheduleById(Long id) throws ValidientException;
    List<Schedule> getSchedulesByYearAndMonth(Long year,Long month) throws ValidientException;
    Optional<Schedule> deleteSchedule(Long scheduleId) throws ValidientException;
}
