package com.validientApi.Validient31.lawyer.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.lawyer.entity.Lawyer;
import com.validientApi.Validient31.lawyer.requests.CreateLawyerRequest;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface LawyerService {
    Optional<Lawyer> createLawyer(Long userId, CreateLawyerRequest lawyer) throws ValidientException;
    Optional<Lawyer> updateLawyer(Long lawyerId, CreateLawyerRequest lawyer) throws ValidientException;
    Set<Lawyer> findLawyers() throws ValidientException;
    Optional<List<Lawyer>> findLawyersByYear(Long registeredYear) throws ValidientException;
    Optional<Lawyer> findLawyerById(Long lawyerId) throws ValidientException;
    Optional<Lawyer> removeLawyerPermissions(Long lawyerId) throws ValidientException;
Optional<Lawyer> addSpecializationToLawyer(Long lawyerId,Long caseType) throws ValidientException;
}
