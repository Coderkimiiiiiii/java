package com.validientApi.Validient31.lawyer.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.caseType.dao.CaseTypeDao;
import com.validientApi.Validient31.caseType.entity.CaseType;
import com.validientApi.Validient31.lawyer.dao.LawyerDao;
import com.validientApi.Validient31.lawyer.entity.Lawyer;
import com.validientApi.Validient31.lawyer.requests.CreateLawyerRequest;
import com.validientApi.Validient31.roles.dao.RoleDao;
import com.validientApi.Validient31.roles.entity.Role;
import com.validientApi.Validient31.users.dao.UserDao;
import com.validientApi.Validient31.users.entity.User;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Transactional
@Data
@AllArgsConstructor
@NoArgsConstructor
@Service
public class LawyerServiceImpl implements LawyerService {
    @Autowired
    private LawyerDao lawyerDao;
    @Autowired
    private CaseTypeDao caseTypeDao;
    @Autowired
    private UserDao userDao;
    @Autowired
    private RoleDao roleDao;

    @Override
    public Optional<Lawyer> createLawyer(Long userId, CreateLawyerRequest lawyer) throws ValidientException {
        if(!userDao.existsById(userId)){
            throw ValidientException.builder().message("Please select correct user").build();
        }
        if(lawyerDao.existsByUser(userDao.findById(userId).get())){
            throw ValidientException.builder().message("Lawyer profile already exist").build();
        }
        Optional<User> existingUser = Optional.of(userDao.findById(userId).get());
       if (!caseTypeDao.existsById(lawyer.getCaseType())){
           throw ValidientException.builder().message("No case type records found").build();
       }
       Optional<CaseType> caseType = caseTypeDao.findById(lawyer.getCaseType());

        Lawyer newLawyer = Lawyer.builder()
                .hourlyRate(lawyer.getHourlyRate())
                .notes(lawyer.getNotes())
                .practiceAreas(lawyer.getPracticeAreas())
                .verifiedYear(lawyer.getVerifiedYear())
                .caseType(caseType.get())
                .user(existingUser.get())
                .build();

        return Optional.of(lawyerDao.save(newLawyer));
    }

    @Override
    public Optional<Lawyer> updateLawyer(Long lawyerId, CreateLawyerRequest data) throws ValidientException {
        Optional<Lawyer> optionalLawyer = lawyerDao.findById(lawyerId);
        if (optionalLawyer == null) {
            throw ValidientException.builder().message("Lawyer details do not exist").metadata("lawyer details not found").statusCode(404).build();
        }
        optionalLawyer.get().setNotes(data.getNotes());
        optionalLawyer.get().setHourlyRate(data.getHourlyRate());
        optionalLawyer.get().setVerifiedYear(data.getVerifiedYear());
        optionalLawyer.get().setPracticeAreas(data.getPracticeAreas());
        return Optional.of(lawyerDao.save(optionalLawyer.get()));

    }

    @Override
    public Set<Lawyer> findLawyers() throws ValidientException {
       Set<Lawyer> lawyers = new HashSet<>(lawyerDao.findAll());
        if (lawyers.stream().toList().toArray().length==0) {
            throw ValidientException.builder().message("No lawyer records").build();
        }
        System.out.println(lawyers);
        return lawyers;
    }

    @Override
    public Optional<List<Lawyer>> findLawyersByYear(Long registeredYear) throws ValidientException {
        Optional<List<Lawyer>> lawyers = Optional.of(lawyerDao.findLawyersByVerifiedYear(registeredYear));
        if (lawyers.stream().toArray().length < 1) {
            throw ValidientException.builder().message("No lawyer records").build();
        }
        return lawyers;
    }

    @Override
    public Optional<Lawyer> findLawyerById(Long lawyerId) throws ValidientException {
        Optional<Lawyer> lawyer = lawyerDao.findById(lawyerId);
        if (lawyer==null) {
            throw ValidientException.builder().message("No lawyer records").build();
        }
        return lawyer;
    }

    @Override
    public Optional<Lawyer> removeLawyerPermissions(Long lawyerId) throws ValidientException {
        Optional<Lawyer> lawyerToDelete = lawyerDao.findById(lawyerId);
        if (lawyerToDelete==null){
            throw ValidientException.builder().message("No lawyer records").build();
        }
        Optional<User> user = userDao.findById(lawyerToDelete.get().getId());
        if (user==null){
            throw ValidientException.builder().message("No user records for lawyer").build();
        }
        Role roleToRemove = roleDao.findRoleByName("lawyer");
        if (roleToRemove==null){
            throw ValidientException.builder().message("Unable to remove lawyer role").build();
        }
        user.get().getRoles().remove(roleToRemove);
        userDao.save(user.get());
//        lawyerDao.deleteById(lawyerId);
        return lawyerToDelete;
    }

    @Override
    public Optional<Lawyer> addSpecializationToLawyer(Long lawyerId,Long caseType) throws ValidientException {
if (!caseTypeDao.existsById(caseType)){
    throw ValidientException.builder().message("No case type records found").build();
}

        if (!lawyerDao.existsById(lawyerId)){
            throw ValidientException.builder().message("No lawyer records found").build();
        }
        Optional<Lawyer> lawyer = lawyerDao.findById(lawyerId);

        return Optional.of(lawyerDao.save(lawyer.get()));
    }

}
