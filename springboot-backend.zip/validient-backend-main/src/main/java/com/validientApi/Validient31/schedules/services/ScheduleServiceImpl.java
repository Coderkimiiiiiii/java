package com.validientApi.Validient31.schedules.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.schedules.dao.ScheduleDao;
import com.validientApi.Validient31.schedules.entity.Schedule;
import com.validientApi.Validient31.schedules.requests.CreateScheduleRequest;
import com.validientApi.Validient31.users.dao.UserDao;
import com.validientApi.Validient31.users.entity.User;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
@NoArgsConstructor
@Transactional
public class ScheduleServiceImpl implements ScheduleService {
    @Autowired
    private ScheduleDao scheduleDao;
    @Autowired
    private UserDao userDao;

    @Override
    public Schedule createSchedule(Long userId, CreateScheduleRequest scheduleRequest) throws ValidientException {
        Optional<User> optionalUser = Optional.of(userDao.findById(userId).get());
        if (optionalUser.isEmpty()) {
            throw ValidientException.builder().message("User does not exist").metadata("create/schedule").build();
        }
        Schedule newSchedule = Schedule.builder()
                .title(scheduleRequest.getTitle())
                .description(scheduleRequest.getDescription())
                .year(scheduleRequest.getYear())
                .month(scheduleRequest.getMonth())
                .date(scheduleRequest.getDate())
                .startHour(scheduleRequest.getStartHour())
                .startMinute(scheduleRequest.getStartMinute())
                .user(optionalUser.get())
                .build();
        return scheduleDao.save(newSchedule);
    }

    @Override
    public Schedule updateSchedule(Long scheduleId, CreateScheduleRequest scheduleRequest) throws ValidientException {
        Optional<Schedule> optionalSchedule = Optional.of(scheduleDao.findById(scheduleId).get());
        if (optionalSchedule.isEmpty()) {
            throw ValidientException.builder().message("Schedule does not exist").metadata("update/failed").statusCode(404).build();
        }
        optionalSchedule.get().setTitle(scheduleRequest.getTitle());
        optionalSchedule.get().setDescription(scheduleRequest.getDescription());
        optionalSchedule.get().setYear(scheduleRequest.getYear());
        optionalSchedule.get().setMonth(scheduleRequest.getMonth());
        optionalSchedule.get().setDate(scheduleRequest.getStartHour());
        optionalSchedule.get().setStartMinute(scheduleRequest.getStartMinute());
        return scheduleDao.save(optionalSchedule.get());


    }

    @Override
    public List<Schedule> getSchedules() throws ValidientException {

        List<Schedule> optionalSchedules = scheduleDao.findAll();
        if (optionalSchedules.toArray().length < 1) {
            throw ValidientException.builder().message("No schedules available").statusCode(404).metadata("user/schedules").build();
        }
        return optionalSchedules;

    }

    @Override
    public List<Schedule> getUserSchedules(Long userId) throws ValidientException {
        List<Schedule> schedules = scheduleDao.findAll();
        if (schedules.isEmpty()) {
            throw ValidientException.builder().message("No schedules available").build();
        }
        return schedules;
    }

    @Override
    public Optional<Schedule> getScheduleById(Long id) throws ValidientException {
        Optional<Schedule> schedule = scheduleDao.findById(id);
        if (schedule == null) {
            throw ValidientException.builder().message("Schedule not found").build();
        }
        return schedule;
    }

    /**
     * @param year
     * @param month
     * @return
     */
    @Override
    public List<Schedule> getSchedulesByYearAndMonth(Long year, Long month) throws ValidientException {
        List<Schedule> schedules = scheduleDao.findByYearAndMonth(year, month);
        if (schedules.toArray().length < 1) {
            throw ValidientException.builder().message("No schedules found").build();
        }
        return schedules;
    }

    /**
     * @param scheduleId
     * @return
     */
    @Override
    public Optional<Schedule> deleteSchedule(Long scheduleId) throws ValidientException {
        Optional<Schedule> schedule = scheduleDao.findById(scheduleId);
        if (schedule == null) {
            throw ValidientException.builder().message("Schedule not found").metadata("Delete/schedule").statusCode(404).build();
        }
        scheduleDao.deleteById(scheduleId);
        return schedule;
    }
}
