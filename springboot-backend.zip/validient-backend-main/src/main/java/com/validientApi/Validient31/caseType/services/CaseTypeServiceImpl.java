package com.validientApi.Validient31.caseType.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.caseType.dao.CaseTypeDao;
import com.validientApi.Validient31.caseType.entity.CaseType;
import com.validientApi.Validient31.caseType.requests.CreateCaseTypeRequest;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
@NoArgsConstructor
@Data
@Transactional
public class CaseTypeServiceImpl implements CaseTypeService {
    @Autowired
    private CaseTypeDao caseTypeDao;
    @Override
    public CaseType createCaseType(CreateCaseTypeRequest caseTypeRequest) {
        if (caseTypeRequest.getName().isEmpty()){
            throw new RuntimeException("Name required");
        } if (caseTypeRequest.getDescription().isEmpty()){
            throw new RuntimeException("Description required");
        }
        Optional<CaseType> optionalCaseType=caseTypeDao.findCaseTypeByName(caseTypeRequest.getName());
        if (optionalCaseType.isPresent()){
            throw new RuntimeException("Case type with name already exist");
        }
        CaseType newCaseType = CaseType.builder()
                .name(caseTypeRequest.getName())
                .description(caseTypeRequest.getDescription())
                .build();
        return caseTypeDao.save(newCaseType);
    }

    @Override
    public CaseType updateCaseType(Long id,CreateCaseTypeRequest updateRequest) throws ValidientException {
    Optional<CaseType> optionalCaseType= Optional.of(caseTypeDao.findById(id).get());
        if (optionalCaseType.isPresent()){
        throw ValidientException.builder().message("Case type with name already exist").metadata("update/casetype").statusCode(404).build();
    }
        if (optionalCaseType.isEmpty()){
            throw new RuntimeException("Case type does not exist");
        }
        optionalCaseType.get().setName(updateRequest.getName());
        optionalCaseType.get().setDescription(updateRequest.getDescription());
        return caseTypeDao.save(optionalCaseType.get());

    }

    @Override
    public Optional<List<CaseType>> findCaseTypes() throws ValidientException {
        List<CaseType> optionalCaseTypes= caseTypeDao.findAll();
        if (optionalCaseTypes==null){
            throw ValidientException.builder().message("No case types available").metadata("case/type/query").build();
        }
        return Optional.of(optionalCaseTypes);
    }

    @Override
    public Optional<CaseType> findCaseByName(String name) throws ValidientException {
        Optional<CaseType> optionalCaseType=caseTypeDao.findCaseTypeByName(name);
        if (optionalCaseType==null){
            throw ValidientException.builder()
                    .message("Case type does not exist")
                    .metadata("find/by/name")
                    .build();
        }
        return optionalCaseType;
    }

    @Override
    public Optional<CaseType> deleteCaseById(Long caseId) throws ValidientException {
        Optional<CaseType> caseType = caseTypeDao.findById(caseId);
        if (caseType==null){
            throw ValidientException.builder()
                    .message("Case type not found")
                    .metadata("delete/case-type")
                    .statusCode(404)
                    .build();
        }
        caseTypeDao.deleteById(caseId);
        return caseType;
    }

    @Override
    public Optional<CaseType> findCaseTypeById(Long caseTypeId) throws ValidientException {
        Optional<CaseType> caseType = caseTypeDao.findById(caseTypeId);
        if (caseType==null){
            throw ValidientException.builder()
                    .message("No case of this id")
                    .metadata("finding/case-by-id")
                    .statusCode(404)
                    .build();
        }
        return caseType;
    }
}
