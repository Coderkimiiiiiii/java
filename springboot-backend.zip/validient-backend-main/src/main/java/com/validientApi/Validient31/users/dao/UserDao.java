package com.validientApi.Validient31.users.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.validientApi.Validient31.users.entity.User;

import java.util.List;

public interface UserDao extends JpaRepository<User, Long>{
    User findByEmailOrUsername(String email, String username);
    Boolean existsByEmailOrUsername(String email,String username);
    Boolean existsByEmail(String email);
    Boolean existsByUsername(String username);
    User findByEmail(String email);
    User findByUsername(String username);
   @Query("SELECT u FROM User u JOIN u.roles r WHERE r.id = :roleId")
   List<User> findByRoleId(Long roleId);
}
