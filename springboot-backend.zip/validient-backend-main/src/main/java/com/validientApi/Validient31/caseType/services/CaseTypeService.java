package com.validientApi.Validient31.caseType.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.caseType.entity.CaseType;
import com.validientApi.Validient31.caseType.requests.CreateCaseTypeRequest;

import java.util.List;
import java.util.Optional;

public interface CaseTypeService {
    CaseType createCaseType(CreateCaseTypeRequest caseTypeRequest);
    CaseType updateCaseType(Long id,CreateCaseTypeRequest updateRequest) throws ValidientException;
    Optional<List<CaseType>> findCaseTypes() throws ValidientException;
    Optional<CaseType> findCaseByName(String name) throws ValidientException;

Optional<CaseType> deleteCaseById(Long caseId) throws ValidientException;
Optional<CaseType> findCaseTypeById(Long caseTypeId) throws ValidientException;
}
