package com.validientApi.Validient31.roles.controllers;

import com.validientApi.Validient31.roles.entity.Role;
import com.validientApi.Validient31.roles.requests.CreateRoleRequest;
import com.validientApi.Validient31.roles.services.RoleService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@NoArgsConstructor
@Data
@RestController
@RequestMapping("/api/v1/roles")
public class RoleController {
    @Autowired
    private RoleService roleService;
    @SneakyThrows
    @GetMapping
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    public ResponseEntity<Optional<Optional<List<Role>>>> getRoles() {
        return ResponseEntity.ok().body(Optional.ofNullable(roleService.findRoles()));
    }
    @SneakyThrows
    @GetMapping("/create")
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    public ResponseEntity<Optional<Role>> createRole(
            @RequestBody @Valid CreateRoleRequest request
    ) {
        return ResponseEntity.ok().body(Optional.ofNullable(roleService.createRole(request)));
    }
    @SneakyThrows
    @GetMapping("/{roleId}/get")
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    public ResponseEntity<Optional<Optional<Role>>> findRoleById(
            @PathVariable @NotBlank @NotNull Long roleId
    ) {
        return ResponseEntity.ok().body(Optional.ofNullable(roleService.findRoleById(roleId)));
    }
    @SneakyThrows
    @PostMapping("/role/{roleName}/get")
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    public ResponseEntity<Optional<Optional<Role>>> findRoleById(
            @PathVariable @NotBlank @NotNull String roleName
    ) {
        return ResponseEntity.ok().body(Optional.of(Optional.ofNullable(roleService.findRoleByName(roleName))));
    }
}
