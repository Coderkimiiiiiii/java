package com.validientApi.Validient31.lawyer.controllers;

import com.validientApi.Validient31.lawyer.entity.Lawyer;
import com.validientApi.Validient31.lawyer.requests.CreateLawyerRequest;
import com.validientApi.Validient31.lawyer.services.LawyerService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.websocket.server.PathParam;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@RestController
@RequestMapping("/api/v1/lawyers")
public class LawyerController {
    @Autowired
    private LawyerService lawyerService;
    @SneakyThrows
    @GetMapping
    @PreAuthorize("hasAnyAuthority({'ADMIN','LAWYER','USER'})")
    public ResponseEntity<Set<Lawyer>> getLawyers(){
        return ResponseEntity.ok().body(lawyerService.findLawyers());
    }
    @SneakyThrows
    @GetMapping("/{lawyerId}/profile")
    @PreAuthorize("hasAnyAuthority({'LAWYER'})")
    public ResponseEntity<Optional<Lawyer>> getUserLawyerProfile(
            @PathVariable @NotBlank @NotNull @NotEmpty Long lawyerId
    ){
        return ResponseEntity.ok().body(lawyerService.findLawyerById(lawyerId));
    }
    @SneakyThrows
    @GetMapping("/{lawyerId}/find")
    @PreAuthorize("hasAnyAuthority({'ADMIN'})")
    public ResponseEntity<Optional<Lawyer>> getLawyerById(
            @PathVariable @NotBlank @NotNull @NotEmpty Long lawyerId
    ){
        return ResponseEntity.ok().body(lawyerService.findLawyerById(lawyerId));
    }
    @SneakyThrows
    @PutMapping("/{lawyerId}/update")
    @PreAuthorize("hasAnyAuthority({'ADMIN','LAWYER'})")
    public ResponseEntity<Optional<Lawyer>> updateLawyerDetails(
            @PathVariable @NotBlank @NotNull @NotEmpty Long lawyerId,
            @RequestBody @Valid CreateLawyerRequest request
            ){
        return ResponseEntity.ok().body(lawyerService.updateLawyer(lawyerId,request));
    }
    @SneakyThrows
    @PutMapping("/{lawyerId}/remove-access")
    @PreAuthorize("hasAnyAuthority({'ADMIN'})")
    public ResponseEntity<Optional<Lawyer>> removeLawyerPermissions(
            @PathVariable @NotBlank @NotNull @NotEmpty Long lawyerId
    ){
        return ResponseEntity.ok().body(lawyerService.removeLawyerPermissions(lawyerId));
    }
    @SneakyThrows
    @GetMapping("/lawyers/filter")
    @PreAuthorize("hasAnyAuthority({'ADMIN'})")
    public ResponseEntity<Optional<List<Lawyer>>> getLawyersByVerificationYear(
            @PathParam("year") @NotBlank @NotNull @NotEmpty Long year
    ){
        return ResponseEntity.ok().body(lawyerService.findLawyersByYear(year));
    }
    @SneakyThrows
    @PatchMapping("/lawyer/{lawyerId}/add-specialization")
    @PreAuthorize("hasAnyAuthority({'ADMIN','LAWYER'})")
    public ResponseEntity<Optional<Lawyer>> addLawyerSpecialization(
            @PathVariable("lawyerId") @NotBlank @NotNull @NotEmpty Long lawyerId,
            @RequestPart("specializations") @NotEmpty @NotNull @NotBlank Long caseType
    ){
        return ResponseEntity.ok().body(lawyerService.addSpecializationToLawyer(lawyerId,caseType));
    }
    @SneakyThrows
    @PostMapping("/lawyer/{userId}/create")
    @PreAuthorize("hasAnyAuthority({'ADMIN','LAWYER'})")
    public ResponseEntity<Optional<Lawyer>> createLawyerProfile(
            @PathVariable("userId") @NotBlank @NotNull @NotEmpty Long userId,
            @RequestBody @Valid CreateLawyerRequest  request
    ){
        return ResponseEntity.ok().body(lawyerService.createLawyer(userId,request));
    }
}
