package com.validientApi.Validient31.users.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.validientApi.Validient31.appointments.entity.Appointment;
import com.validientApi.Validient31.roles.entity.Role;
import com.validientApi.Validient31.schedules.entity.Schedule;
import com.validientApi.Validient31.users.enums.Gender;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table
@JsonIgnoreProperties({"hibernateLazyInitializer"})
//@ToString
public class User implements UserDetails {
    @Id
    @GeneratedValue
    private Long id;
    @Column(unique = true, nullable = false)
    private String email;
    @ToString.Exclude
    @JsonIgnore
    private String password;
    @Column(unique = true, nullable = false)
    private String username;
    private String firstName;
    private String lastName;
    private String avatar="";
    @Enumerated(EnumType.STRING)
    private Gender gender;
    @ManyToMany(fetch = FetchType.EAGER,cascade ={CascadeType.MERGE,CascadeType.REFRESH})
    @JoinTable(name = "user_with_roles",
            joinColumns = {@JoinColumn(name = "user_side_id")},
            inverseJoinColumns = {@JoinColumn(name = "role_side_id")})
    @Schema(accessMode = Schema.AccessMode.READ_ONLY)
    private Set<Role> roles=new HashSet<>();
    @OneToMany
    @JoinColumn(referencedColumnName = "id")
    private Set<Appointment> appointments=new HashSet<>();

//    @ToString.Exclude
    @OneToMany(mappedBy = "user",fetch = FetchType.LAZY, cascade = {CascadeType.MERGE,CascadeType.PERSIST})
    private Set<Schedule> userSchedules=new HashSet<>();

    /**
     * Disabled this to avoid stack overflow error on recursive call of null user with token
     */
//     @JsonManagedReference
//     @OneToMany(mappedBy = "user")
//     private List<Token> tokens;

    /**
     * @return
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return roles.stream().map(r -> new SimpleGrantedAuthority(r.getName().toUpperCase())).collect(Collectors
                .toList() );
    }

    /**
     * @return
     */
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    /**
     * @return
     */
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    /**
     * @return
     */
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    /**
     * @return
     */
    @Override
    public boolean isEnabled() {
        return true;
    }
}