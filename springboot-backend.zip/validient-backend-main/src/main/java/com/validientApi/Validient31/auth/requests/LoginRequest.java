package com.validientApi.Validient31.auth.requests;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LoginRequest {

    @NotBlank
    @NotNull
    @NotEmpty
    private String username;
    @NotNull
    @NotBlank
    @Size(min = 8,max = 32,message = "Password should have minimum of 8-32 characters")
    String password;
}
