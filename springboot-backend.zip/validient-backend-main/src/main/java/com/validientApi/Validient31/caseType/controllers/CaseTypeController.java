package com.validientApi.Validient31.caseType.controllers;

import com.validientApi.Validient31.caseType.entity.CaseType;
import com.validientApi.Validient31.caseType.requests.CreateCaseTypeRequest;
import com.validientApi.Validient31.caseType.services.CaseTypeService;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@NoArgsConstructor
@RestController
@RequestMapping("/api/v1/case-type")
public class CaseTypeController {
    @Autowired
    private CaseTypeService caseTypeService;

    @PostMapping
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN'})")
    public ResponseEntity<CaseType> createCaseType(
            @RequestBody CreateCaseTypeRequest request
    ) {
        return ResponseEntity.ok().body(caseTypeService.createCaseType(request));
    }

    @PutMapping("/{caseTypeId}/update")
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN'})")
    public ResponseEntity<CaseType> updateCaseType(
            @PathVariable("caseTypeId") @NotNull @NotEmpty @NotBlank Long caseTypeId,
            @RequestBody CreateCaseTypeRequest request
    ) {
        return ResponseEntity.ok().body(caseTypeService.updateCaseType(caseTypeId, request));
    }

    @GetMapping("/query/{caseTypeName}")
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN','USER','LAWYER'})")
    public ResponseEntity<Optional<CaseType>> getCaseTypeByName(
            @PathVariable("caseTypeName") @NotNull @NotEmpty @NotBlank String caseTypeName

    ) {
        return ResponseEntity.ok().body(caseTypeService.findCaseByName(caseTypeName));
    }

    @GetMapping
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN','USER','LAWYER'})")
    public ResponseEntity<List<CaseType>> getCaseTypes() {
        return ResponseEntity.ok().body(caseTypeService.findCaseTypes().get());
    }

    @DeleteMapping("/{caseId}/delete")
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN'})")
    public ResponseEntity<Optional<CaseType>> deleteCaseTypeById(
            @PathVariable("caseId") @NotNull @NotEmpty @NotBlank Long caseId
    ) {
        return ResponseEntity.ok().body(caseTypeService.deleteCaseById(caseId));
    }

    @GetMapping("/{caseId}/get")
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN','USER','LAWYER'})")
    public ResponseEntity<Optional<CaseType>> getCaseTypeById(
            @PathVariable("caseId") @NotNull @NotEmpty @NotBlank Long caseId
    ) {
        return ResponseEntity.ok().body(caseTypeService.findCaseTypeById(caseId));
    }
}

