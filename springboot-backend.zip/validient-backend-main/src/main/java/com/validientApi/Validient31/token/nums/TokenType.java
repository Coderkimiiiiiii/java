package com.validientApi.Validient31.token.nums;

public enum TokenType {
        BEARER
}
