package com.validientApi.Validient31.caseStatus.controllers;

import com.validientApi.Validient31.caseStatus.entity.CaseStatus;
import com.validientApi.Validient31.caseStatus.requests.CreateCaseStatusRequest;
import com.validientApi.Validient31.caseStatus.services.CaseStatusService;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@NoArgsConstructor
@RestController
@RequestMapping("/api/v1/case-status")
public class CaseStatusController {
    @Autowired
    private CaseStatusService caseStatusService;

    @PostMapping
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN'})")
    public ResponseEntity<CaseStatus> createCaseStatus(
            @RequestBody CreateCaseStatusRequest request
    ) {
        return ResponseEntity.ok().body(caseStatusService.createCaseStatus(request));
    }

    @PutMapping("/{caseStatusId}/update")
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN'})")
    public ResponseEntity<CaseStatus> updateCaseStatus(
            @PathVariable Long caseStatusId,
            @RequestBody CreateCaseStatusRequest request
    ) {
        return ResponseEntity.ok().body(caseStatusService.updateCaseStatusById(caseStatusId, request));
    }

    @GetMapping("/query/{CaseStatusName}")
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN','USER','LAWYER'})")
    public ResponseEntity<Optional<CaseStatus>> getCaseStatusByName(
            @PathVariable String CaseStatusName

    ) {
        return ResponseEntity.ok().body(caseStatusService.findStatusByName(CaseStatusName));
    }

    @GetMapping
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN','USER','LAWYER'})")
    public ResponseEntity<Optional<List<CaseStatus>>> getCaseStatuses() {
        return ResponseEntity.ok().body(caseStatusService.findCaseStatuses());
    }

    @DeleteMapping("/{caseId}/delete")
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN'})")
    public ResponseEntity<Optional<CaseStatus>> deleteCaseStatusById(
            @PathVariable("caseId") @NotNull @NotEmpty @NotBlank Long caseId
    ) {
        return ResponseEntity.ok().body(caseStatusService.deleteCaseStatus(caseId));
    }

    @GetMapping("/{caseId}/get")
    @SneakyThrows
    @PreAuthorize("hasAuthority({'ADMIN','USER','LAWYER'})")
    public ResponseEntity<Optional<CaseStatus>> getCaseStatusById(
            @PathVariable("caseId") @NotNull @NotEmpty @NotBlank Long caseId
    ) {
        return ResponseEntity.ok().body(caseStatusService.findStatusById(caseId));
    }
}
