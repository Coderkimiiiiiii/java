package com.validientApi.Validient31.caseFiling.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CreateCaseFilingRequest {
    @NotBlank
    @NotNull
    @NotEmpty
    private String title;
    @NotBlank
    @NotNull
    @NotEmpty
    private String description;

    @NotNull
    private Long caseType;
    @NotNull
    private Long status;
    @NotNull
    private Long lawyer;
    @NotBlank
    @NotNull
    @NotEmpty
    private String dateFiled;
}
