package com.validientApi.Validient31.users.controllers;

import com.validientApi.Validient31.users.entity.User;
import com.validientApi.Validient31.users.requests.CreateUserWithRolesRequest;
import com.validientApi.Validient31.users.requests.UpdateUserPasswordRequest;
import com.validientApi.Validient31.users.requests.UpdateUserWithoutPasswordRequest;
import com.validientApi.Validient31.users.services.UserService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@RestController
@RequestMapping("/api/v1/users")
public class UserController {
    @Autowired
    private  UserService userService;

    @SneakyThrows
    @GetMapping
    public ResponseEntity<List<User>> findUsers(){
        return ResponseEntity.ok().body( userService.findUsers());
    }
    @SneakyThrows
    @GetMapping("/user/{userId}/profile")
    public ResponseEntity<Optional<User>> findUserById(@PathVariable("userId") @NotNull Long userId){
        return ResponseEntity.ok().body( userService.findUserById(userId));
    }

    @SneakyThrows
    @PostMapping("/new")
    @PreAuthorize("hasAuthority({'ADMIN','LAWYER','USER'})")
    public User createUserWithRoles(@RequestBody @Valid CreateUserWithRolesRequest request){
        return userService.createUserWithRoles(request);
    }
    @SneakyThrows
    @PutMapping("/{userId}/update")
    @PreAuthorize("hasAuthority({'ADMIN','LAWYER','USER'})")
    public User updateUserWithRole(@RequestBody @Valid UpdateUserWithoutPasswordRequest request, @PathVariable @NotEmpty Long userId){
        return userService.updateUserWithoutPassword(userId,request);
    }
    @SneakyThrows
    @PatchMapping("/{userId}/update/password")
    @PreAuthorize("hasAuthority({'ADMIN','LAWYER','USER'})")
    public User updatePassword(@RequestBody @Valid UpdateUserPasswordRequest request, @PathVariable @NotEmpty Long userId){
        return userService.updateUserPassword(userId,request);
    }
    @SneakyThrows
    @PatchMapping("/{userId}/update/remove-role")
    @PreAuthorize("hasAuthority({'ADMIN'})")
    public User removeUserRoles(@RequestPart @Valid Set<Long> request, @PathVariable @NotEmpty Long userId){
        return userService.removeRolesFromUser(userId,request);
    }
    @SneakyThrows
    @PatchMapping("/{userId}/update/add-role")
    @PreAuthorize("hasAuthority({'ADMIN'})")
    public User addRoleToUser(@RequestPart @Valid Set<Long> useRoles, @PathVariable @NotEmpty Long userId){
        return userService.addRolesToUser(userId,useRoles);
    }
}
