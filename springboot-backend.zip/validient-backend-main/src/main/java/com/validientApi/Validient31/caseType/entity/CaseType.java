package com.validientApi.Validient31.caseType.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.validientApi.Validient31.caseFiling.entity.CaseFiling;
import com.validientApi.Validient31.lawyer.entity.Lawyer;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Data
@JsonIgnoreProperties({"hibernateLazyInitializer"})
@JsonSerialize
public class CaseType {
    @Id
    @GeneratedValue
    private Long id;
    @Column(nullable = false)
    private String name;
    @Lob
    private String description;
    @OneToMany(mappedBy="caseType" ,cascade= {CascadeType.PERSIST,CascadeType.MERGE},fetch = FetchType.LAZY)
    @JsonIgnore
    @ToString.Exclude
    private List<CaseFiling> caseFiles;
    @OneToMany(mappedBy="caseType", cascade= {CascadeType.PERSIST,CascadeType.MERGE},fetch = FetchType.LAZY)
    @JsonIgnore
    @ToString.Exclude
    private List<Lawyer> lawyers;
}
