package com.validientApi.Validient31.users.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.auth.responses.LoginResponse;
import com.validientApi.Validient31.auth.responses.RegistrationResponse;
import com.validientApi.Validient31.auth.services.AuthService;
import com.validientApi.Validient31.config.JwtService;
import com.validientApi.Validient31.roles.dao.RoleDao;
import com.validientApi.Validient31.roles.entity.Role;
import com.validientApi.Validient31.token.dao.TokenDao;
import com.validientApi.Validient31.token.entity.Token;
import com.validientApi.Validient31.token.nums.TokenType;
import com.validientApi.Validient31.users.dao.UserDao;
import com.validientApi.Validient31.users.entity.User;
import com.validientApi.Validient31.users.requests.CreateUserRequest;
import com.validientApi.Validient31.users.requests.CreateUserWithRolesRequest;
import com.validientApi.Validient31.users.requests.UpdateUserPasswordRequest;
import com.validientApi.Validient31.users.requests.UpdateUserWithoutPasswordRequest;
import com.validientApi.Validient31.utils.MD5UserAvatar;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@NoArgsConstructor
@Transactional
@Data
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;
    @Autowired
    private TokenDao tokenDao;
    @Autowired
    private JwtService jwtService;
    @Autowired
    private RoleDao roleDao;
    @Autowired
    private AuthService authService;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public User createUser(CreateUserRequest userRequest) {
        Role defaultRole = roleDao.findDefaultRole(true);

        User newUser = User.builder()
                .gender(userRequest.getGender())
                .firstName(userRequest.getFirstName())
                .lastName(userRequest.getLastName())
                .password(userRequest.getPassword())
                .username(userRequest.getUsername())
                .build();
        return userDao.save(newUser);

    }

    @Override
    public User creatUserWithRole(CreateUserRequest user, Long roleId) throws ValidientException {

        if (userDao.existsByUsername(user.getUsername())) {
            throw ValidientException
                    .builder()
                    .message("Username already exist")
                    .statusCode(401)
                    .metadata("user/registration")
                    .build();

        }
        if (userDao.existsByUsername(user.getEmail())) {
            throw ValidientException.builder().message("User email already exist").build();
        }
        if (!roleDao.existsById(roleId)) {
            throw ValidientException.builder().message("Role does not exist").build();
        }
        User newUser = User.builder()
                .gender(user.getGender())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .password(passwordEncoder.encode(user.getPassword()))
                .username(user.getUsername())
                .email(user.getEmail())
                .avatar(MD5UserAvatar.generateAvatar(user.getEmail()))
                .roles(Set.of(roleDao.findDefaultRole(true)))
                .build();
        var savedUser = userDao.save(newUser);
        var jwtToken = jwtService.generateToken(newUser);
        saveUserToken(savedUser, jwtToken);
        LoginResponse loginResponse = LoginResponse.builder()
                .token(jwtToken).build();
        RegistrationResponse registrationResponse = RegistrationResponse.builder()
                .auth(loginResponse)
                .user(savedUser)
                .build();

        return registrationResponse.getUser();
    }
    private void saveUserToken(User user, String jwtToken) {
        var token = Token.builder()
                .user(user)
                .token(jwtToken)
                .tokenType(TokenType.BEARER)
                .expired(false)
                .revoked(false)
                .build();
        tokenDao.save(token);
    }

    @Override
    public List<User> findUsers() throws ValidientException {
        List<User> users = new ArrayList<>(userDao.findAll());
        if (users.toArray().length < 1) {
            throw ValidientException.builder().message("No user records").metadata("user/fetch").statusCode(404).build();
        }
        return users;
    }

    @Override
    public User findUserByEmail(String email) throws ValidientException {
        User user = userDao.findByEmail(email);
        if (user == null) {
            throw ValidientException.builder().message("User not found").statusCode(404).build();
        }
        return user;
    }

    @Override
    public User findUserByUsername(String username) throws ValidientException {

        if (!userDao.existsByUsername(username)) {
            throw ValidientException.builder().message("User not found").build();
        }
        return userDao.findByEmail(username);
    }

    @Override
    public Optional<User> findUserById(Long id) throws ValidientException {

        if (!userDao.existsById(id)) {
            throw ValidientException.builder().message("User account does not exist").build();
        }
        return userDao.findById(id);
    }

    @SneakyThrows
    @Override
    public User removeRolesFromUser(Long userId,Set<Long> roles) {
        if (!userDao.existsById(userId)) {
            throw ValidientException.builder().message("No user record").build();
        }
        User user = userDao.findById(userId).get();
        roles.forEach(role -> {
            if (roleDao.existsById(role)) {
                Optional<Role> role1 = roleDao.findById(role);
                if (user.getRoles().contains(role1)) {
                    user.getRoles().remove(role1);
                }
            }
        });
        return userDao.save(user);
    }

    @SneakyThrows
    @Override
    public User addRolesToUser(Long userId, Set<Long> roles) {
        if (!userDao.existsById(userId)) {
            throw ValidientException.builder().message("No user record").build();
        }
        User user = userDao.findById(userId).get();
        Arrays.stream(roles.toArray()).toList().forEach(role -> {
            if (roleDao.existsById((Long) role)) {
                Optional<Role> role1 = roleDao.findById((Long) role);
                if (!user.getRoles().contains(role1)) {
                    user.getRoles().add(role1.get());
                }
            }
        });
        return userDao.save(user);
    }

    @Override
    public User createUserWithRoles(CreateUserWithRolesRequest request) throws ValidientException {
        if (userDao.existsByUsername(request.getUsername())){
           throw ValidientException.builder().message("Username already taken").build();
        }
        if (userDao.existsByEmail(request.getEmail())){
          throw  ValidientException.builder().message("Email already taken").build();
        }
        Set<Role> roles = roleDao.findAll().stream().filter(role -> request.getRoles().contains(role.getId())).collect(Collectors.toSet());
        User newUser= User.builder()
                .gender(request.getGender())
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .avatar(MD5UserAvatar.generateAvatar(request.getEmail()))
                .roles(roles)
                .build();
        return userDao.save(newUser);
    }

    @Override
    public User updateUserWithoutPassword(Long userId, UpdateUserWithoutPasswordRequest request) throws ValidientException {
        if (!userDao.existsById(userId)){
            throw ValidientException.builder().message("User does not exist").build();
        }
        User user = userDao.findById(userId).get();
        user.setGender(request.getGender());
               user.setFirstName(request.getFirstName());
                user.setLastName(request.getLastName());
                user.setUsername(request.getUsername());
                user.setEmail(request.getEmail());
                user.setAvatar(MD5UserAvatar.generateAvatar(request.getEmail()));
        return userDao.save(user);
    }

    @Override
    public User updateUserPassword(Long userId, UpdateUserPasswordRequest request) throws ValidientException {
        if (!userDao.existsById(userId)){
            throw ValidientException.builder().message("User does not exist").build();
        }
        User user = userDao.findById(userId).get();
       user.setPassword(passwordEncoder.encode(request.getPassword()));

        return userDao.save(user);
    }

    @Override
    public List<User> findUsersByRole(Long role) throws ValidientException {
        Optional<Role> optionalRole = roleDao.findById(role);
        if (optionalRole.isEmpty()) {
            throw ValidientException.builder().message("Role does not exist").build();
        }
        List<User> users = userDao.findAll();//.stream().filter(u -> u.getRoles().contains(optionalRole)).collect(Collectors.toList()));
        if (users.toArray().length < 1) {
            throw ValidientException.builder()
                    .message("No users found")
                    .statusCode(404)
                    .metadata("user-role/no-entry")
                    .build();
        }
        return users;

    }
}
