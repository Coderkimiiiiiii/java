package com.validientApi.Validient31.caseDefendant.controllers;

import com.validientApi.Validient31.caseDefendant.entity.CaseDefendant;
import com.validientApi.Validient31.caseDefendant.requests.CreateCaseDefendant;
import com.validientApi.Validient31.caseDefendant.services.CaseDefendantService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/defendants")
@RequiredArgsConstructor
public class CaseDefendantController {
    @Autowired
    private CaseDefendantService caseDefendantService;

    @SneakyThrows
    @GetMapping
    @PreAuthorize("hasAnyAuthority({'ADMIN','LAWYER'})")
    public ResponseEntity<List<CaseDefendant>> findDefendants(){
        return ResponseEntity.ok().body(caseDefendantService.findDefendants());

    }
    @SneakyThrows
    @GetMapping("/{defendantId}/get")
    @PreAuthorize("hasAnyAuthority({'ADMIN','LAWYER'})")
    public ResponseEntity<Optional<CaseDefendant>> findDefendantById(@PathVariable("defendantId") @NotBlank @NotEmpty @NotNull Long defendantId){
        return ResponseEntity.ok().body(caseDefendantService.findCaseDefendantById(defendantId));

    }
    @SneakyThrows
    @DeleteMapping("/{defendantId}/delete")
    @PreAuthorize("hasAuthority({'ADMIN'})")
    public ResponseEntity<Optional<CaseDefendant>> deleteCaseDefendant(@PathVariable("defendantId") @NotBlank @NotEmpty @NotNull Long defendantId){
        return ResponseEntity.ok().body(caseDefendantService.deleteCaseDefendant(defendantId));

    }
    @SneakyThrows
    @PostMapping("/create")
    @PreAuthorize("hasAuthority({'ADMIN'})")
    public ResponseEntity<Optional<Object>> createCaseDefendant(@RequestBody @Valid CreateCaseDefendant request){
        return ResponseEntity.ok().body(caseDefendantService.createCaseDefendant(request));

    }
    @SneakyThrows
    @PutMapping("/{defendantId}/update")
    @PreAuthorize("hasAuthority({'ADMIN','LAWYER'})")
    public ResponseEntity<Optional<CaseDefendant>> updateCaseDefendant(@PathVariable("defendantId") @NotBlank @NotEmpty @NotNull Long defendantId,@RequestBody @Valid CreateCaseDefendant request){
        return ResponseEntity.ok().body(caseDefendantService.updateCaseDefendant(defendantId,request));

    }
}
