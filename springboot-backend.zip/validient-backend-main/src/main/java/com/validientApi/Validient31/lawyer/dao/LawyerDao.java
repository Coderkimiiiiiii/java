package com.validientApi.Validient31.lawyer.dao;


import com.validientApi.Validient31.lawyer.entity.Lawyer;
import com.validientApi.Validient31.users.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LawyerDao extends JpaRepository<Lawyer, Long> {
    List<Lawyer> findLawyersByVerifiedYear(Long year);
    Optional<List<Lawyer>> findLawyersByIdIsIn(Long[] lawyerIds);
    Boolean existsByUser(User user);

}
