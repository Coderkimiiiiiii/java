package com.validientApi.Validient31.caseFiling.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.caseFiling.entity.CaseFiling;
import com.validientApi.Validient31.caseFiling.requests.CreateCaseFilingRequest;

import java.util.List;
import java.util.Optional;

public interface CaseFilingService {
    Optional<CaseFiling> createCaseFiling(Long plaintiffId,CreateCaseFilingRequest caseFilingRequest) throws ValidientException;
    Optional<CaseFiling> updateCaseFiling(Long caseId,CreateCaseFilingRequest caseFilingRequest) throws ValidientException;
    Optional<CaseFiling> addLawyerToCaseFiling(Long caseId,Long lawyer) throws ValidientException;
    Optional<CaseFiling> removeLawyerFromCaseFiling(Long caseId,Long lawyer) throws ValidientException;
    Optional<List<CaseFiling>> findCases() throws ValidientException;
    Optional<List<CaseFiling>> findCasesWithStatus(Long status) throws ValidientException;
    Optional<List<CaseFiling>> findCasesWithType(Long caseType) throws ValidientException;
    Optional<List<CaseFiling>> findUserCases(Long userId) throws ValidientException;
    Optional<CaseFiling> findCaseFilingById(Long id) throws ValidientException;
}
