package com.validientApi.Validient31.auth.services;

import com.validientApi.Validient31.advice.ValidientException;
import com.validientApi.Validient31.auth.requests.LoginRequest;
import com.validientApi.Validient31.auth.requests.RegisterRequest;
import com.validientApi.Validient31.auth.responses.LoginResponse;
import com.validientApi.Validient31.auth.responses.RegistrationResponse;
import com.validientApi.Validient31.config.JwtService;
import com.validientApi.Validient31.roles.dao.RoleDao;
import com.validientApi.Validient31.roles.entity.Role;
import com.validientApi.Validient31.token.dao.TokenDao;
import com.validientApi.Validient31.token.entity.Token;
import com.validientApi.Validient31.token.nums.TokenType;
import com.validientApi.Validient31.users.dao.UserDao;
import com.validientApi.Validient31.users.entity.User;
import com.validientApi.Validient31.users.enums.Gender;
import com.validientApi.Validient31.utils.MD5UserAvatar;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
@RequiredArgsConstructor
@Transactional
public class AuthService {
    private final UserDao userDao;
    @Autowired
    private RoleDao roleDao;
    private final TokenDao tokenDao;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;


    public RegistrationResponse register(RegisterRequest request) throws ValidientException {

        Optional<Role> defaultRole= Optional.ofNullable(this.validateUserExistAndGetDefaultRole(request, userDao, roleDao));
        User newUser= User.builder()
                .gender(request.getGender())
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .password(passwordEncoder.encode(request.getPassword()))
                .username(request.getUsername())
                .email(request.getEmail())
                .avatar(MD5UserAvatar.generateAvatar(request.getEmail()))
                .roles(Set.of(defaultRole.get()))
                .build();
        var savedUser = userDao.save(newUser);
        var jwtToken = jwtService.generateToken(newUser);
        saveUserToken(savedUser, jwtToken);
        LoginResponse loginResponse= LoginResponse.builder()
                .token(jwtToken).build();
        RegistrationResponse registrationResponse= RegistrationResponse.builder()
                .auth(loginResponse)
                .user(savedUser)
                .build();
        return registrationResponse;
    }

    public  Role validateUserExistAndGetDefaultRole(RegisterRequest request, UserDao userDao, RoleDao roleDao) throws ValidientException {
        if (request.getGender()==null){
            request.setGender(Gender.OTHER);
        }
        if (request.getGender().toString().toLowerCase()=="male"){
            request.setGender(Gender.MALE);
        }
        if (request.getGender().toString().toLowerCase()=="female"){
            request.setGender(Gender.FEMALE);
        }
       User user = userDao.findByEmailOrUsername(request.getEmail(), request.getUsername());

        if(user!=null){
            if (user.getEmail().toString()==request.getEmail().toString()){
                throw  ValidientException
                        .builder()
                        .message("User email already exist")
                        .statusCode(409).metadata("account/conflict")
                        .build();
            }if (user.getUsername().equals(request.getUsername())){
                throw ValidientException
                        .builder().message("User email already exist").build();
            }
        }
        Role defaultRole = roleDao.findDefaultRole(true);
        if (defaultRole==null){
            throw  ValidientException
                    .builder()
                    .message("Please initialize roles first").metadata("/role").statusCode(500).build();
        }
        return defaultRole;
    }

    public User getUserprofile(String username) throws ValidientException {
        User optUser= userDao.findByUsername(username);
        if (optUser==null){
            throw ValidientException.builder().message("Profile not found").metadata("/profile-fetch").statusCode(404).build();
        }
        return optUser;
    }

    public LoginResponse authenticate(LoginRequest request) throws ValidientException {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword()
                )
        );
        var user = userDao.findByUsername(request.getUsername());
               if (user==null){
                   throw ValidientException.builder().message("User account not found").build();
               }
        var jwtToken = jwtService.generateToken(user);
        revokeAllUserTokens(user);
        saveUserToken(user, jwtToken);
        return LoginResponse.builder()
                .token(jwtToken)
                .user(user)
                .build();
    }

    private void saveUserToken(User user, String jwtToken) {
        var token = Token.builder()
                .user(user)
                .token(jwtToken)
                .tokenType(TokenType.BEARER)
                .expired(false)
                .revoked(false)
                .build();
        tokenDao.save(token);
    }

    private void revokeAllUserTokens(User user) {
        var validUserTokens = tokenDao.findAllValidTokenByUser(user.getId());
        if (validUserTokens.isEmpty())
            return;
        validUserTokens.forEach(token->tokenDao.deleteById(Math.toIntExact(token.getId())));
    }
}