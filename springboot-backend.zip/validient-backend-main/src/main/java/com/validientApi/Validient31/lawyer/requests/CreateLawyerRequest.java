package com.validientApi.Validient31.lawyer.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Null;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class CreateLawyerRequest {
    @NotNull
    private Long  verifiedYear;
    @NotNull
    private Long hourlyRate;
    @NotNull
    @NotEmpty
    @NotBlank
    private String practiceAreas;
    @NotNull
    @NotEmpty
    @NotBlank
    private String notes;
    @NotNull
    private Long caseType;
}
